"""Barcha foydalanuvchi matnlari (o'zbek tilida) bir joyda."""
from __future__ import annotations

from html import escape

BRAND = "💠 <b>N E X O R A</b> 💠"
DIV = "━━━━━━━━━━━━━━━━━━"

FEATURES = {
    "ai": "🤖 AI Yordamchi",
    "education": "🎓 Ta'lim Markazi",
    "creative": "🎨 Ijodiy Markaz",
    "daily": "📅 Kundalik Yordamchi",
    "games": "🎮 Mini O'yinlar",
}

ACTION_LABELS = {
    "ai_chat": "🤖 AI suhbat",
    "ai_translate": "🌐 Tarjima",
    "ai_code": "💻 Kod yordami",
    "ai_edit": "✍️ Matn tahriri",
    "ai_tutor": "👨‍🏫 Ingliz tili savol-javobi",
    "image": "🖼 Rasm yaratish",
    "imgprompt": "🪄 Rasm prompti",
    "story": "📖 Hikoya",
    "poem": "🪶 She'r",
    "script": "🎬 Video ssenariy",
    "vprompt": "🎞 Video prompt",
    "vocab": "📖 Lug'at kartochkasi",
    "quiz_ok": "✅ To'g'ri javob",
    "quiz_bad": "❌ Noto'g'ri javob",
    "daily_quiz": "📆 Kunlik sinov",
    "task_add": "➕ Vazifa qo'shildi",
    "task_done": "✔️ Vazifa bajarildi",
    "reminder_add": "⏰ Eslatma qo'shildi",
}


def esc(text: str | None) -> str:
    return escape(text or "", quote=False)


def welcome(name: str, is_new: bool) -> str:
    greet = "Xush kelibsiz" if is_new else "Qaytganingiz bilan"
    return (
        f"{BRAND}\n{DIV}\n"
        f"✨ {greet}, <b>{esc(name)}</b>!\n\n"
        "NEXORA — bitta botda <b>aqlli yordamchi</b>, <b>ta'lim</b>, <b>ijod</b>, "
        "<b>kundalik reja</b> va <b>o'yinlar</b>.\n\n"
        "👇 Kerakli bo'limni tanlang:"
    )


MAIN_MENU = f"{BRAND}\n{DIV}\n🏠 <b>Bosh menyu</b>\nKerakli bo'limni tanlang 👇"

HELP = (
    f"{BRAND}\n{DIV}\nℹ️ <b>Yordam</b>\n\n"
    "🤖 <b>AI Yordamchi</b> — suhbat, tarjima, kod, matn tahriri\n"
    "🎓 <b>Ta'lim Markazi</b> — lug'at, ingliz tili testlari, kunlik sinov\n"
    "🎨 <b>Ijodiy Markaz</b> — rasm, hikoya, she'r, video ssenariy\n"
    "📅 <b>Kundalik Yordamchi</b> — eslatma, vazifa, reja, statistika\n"
    "🎮 <b>Mini O'yinlar</b> — viktorina, topishmoq, mantiq, reyting\n\n"
    "<b>Buyruqlar:</b>\n"
    "/start — bosh menyu\n/menu — menyuni ochish\n/profile — profilim\n"
    "/top — reyting\n/cancel — joriy amalni bekor qilish\n\n"
    "💡 Biror bo'limda adashib qolsangiz, /start yuboring."
)

AI_MENU = (
    f"{BRAND}\n{DIV}\n🤖 <b>AI Yordamchi</b>\n\n"
    "Rejimni tanlang. Tanlangach, shunchaki xabar yozing — AI javob beradi.\n"
    "💬 Suhbat tarixi saqlanadi (tarjimadan tashqari)."
)
AI_NOT_CONFIGURED = (
    "⚠️ AI xizmati hali sozlanmagan.\n"
    "Administrator <code>.env</code> faylida <code>AI_API_KEY</code> ni kiritishi kerak."
)
AI_MODE_INTRO = {
    "chat": "💬 <b>Suhbat rejimi</b>\nIstalgan savolingizni yozing.",
    "translate": "🌐 <b>Tarjima rejimi</b>\nMatn yuboring: o'zbekchadan inglizchaga, boshqa tildan o'zbekchaga tarjima qilinadi.\n"
                 "Aniq til uchun: <i>ruscha: Salom, qalaysiz?</i>",
    "code": "💻 <b>Kod yordamchisi</b>\nKod so'rang, xatoni yuboring yoki kodni tushuntirishni so'rang.",
    "edit": "✍️ <b>Matn yozish va tahrirlash</b>\nMatningizni yuboring (tahrir uchun) yoki nima yozish kerakligini ayting.",
    "tutor": "👨‍🏫 <b>Ingliz tili savol-javobi</b>\nGrammatika, so'z yoki iboralar haqida o'zbek tilida so'rang.",
}
AI_LIMIT = "⏳ Bugungi AI so'rovlar limitingiz ({n} ta) tugadi. Ertaga qayta urinib ko'ring."
AI_BUSY = "⏳ Oldingi so'rovingiz hali bajarilmoqda, biroz kuting..."

EDU_MENU = (
    f"{BRAND}\n{DIV}\n🎓 <b>Ta'lim Markazi</b>\n\n"
    "Ingliz tilini o'rganing, bilimingizni sinang va ball to'plang!"
)
GAMES_MENU = (
    f"{BRAND}\n{DIV}\n🎮 <b>Mini O'yinlar</b>\n\n"
    "To'g'ri javob uchun ball beriladi:\n"
    "🎯 Viktorina +5 • 🕵️ Topishmoq +7 • 🧩 Mantiq +10\n"
    "<i>Bir savol uchun kuniga bir marta ball olinadi.</i>"
)
CREATIVE_MENU = (
    f"{BRAND}\n{DIV}\n🎨 <b>Ijodiy Markaz</b>\n\n"
    "Rasm, hikoya, she'r va video g'oyalarini AI bilan yarating."
)
CREATIVE_PROMPTS = {
    "img": "🖼 <b>Rasm yaratish</b>\nRasmda nima bo'lishini yozing (masalan: <i>tog' ustidagi futuristik shahar, kechasi, neon</i>).\n"
           "AI buni inglizcha batafsil promptga aylantiradi.",
    "imgprompt": "🪄 <b>Rasm uchun prompt</b>\nG'oyangizni yozing — Midjourney/DALL-E/Flux uchun tayyor promptlar beraman.",
    "story": "📖 <b>Hikoya</b>\nMavzu yoki g'oyani yozing (masalan: <i>yo'qolgan robot o'z uyini qidiradi</i>).",
    "poem": "🪶 <b>She'r</b>\nMavzuni yozing (masalan: <i>Vatan</i>, <i>bahor</i>, <i>do'stlik</i>).",
    "script": "🎬 <b>Video ssenariy</b>\nVideo g'oyasini yozing (masalan: <i>30 soniyalik Toshkent haqida reklama</i>).",
    "vprompt": "🎞 <b>Video prompt</b>\nVideo g'oyasini yozing — AI-video generatorlar uchun prompt tayyorlayman.",
}

DAILY_MENU = (
    f"{BRAND}\n{DIV}\n📅 <b>Kundalik Yordamchi</b>\n\n"
    "Eslatmalar, vazifalar va kunlik reja — hammasi shu yerda."
)
REMINDER_HELP = (
    "⏰ <b>Yangi eslatma</b>\n\nVaqt va matnni birga yozing:\n"
    "• <code>18:30 Dori ichish</code> — bugun/ertaga shu vaqtda\n"
    "• <code>25.12 09:00 Tug'ilgan kun</code> — sana bilan\n"
    "• <code>25.12.2026 09:00 Imtihon</code> — to'liq sana\n"
    "• <code>+30 Choyni o'chirish</code> — 30 daqiqadan keyin"
)
REMINDER_BAD = "⚠️ Format noto'g'ri yoki vaqt o'tib ketgan.\n\n" + REMINDER_HELP


def bar(n: int, mx: int, width: int = 8) -> str:
    if mx <= 0 or n <= 0:
        return "▱" * 2
    filled = max(1, round(n / mx * width))
    return "▰" * filled


def rank_medal(i: int) -> str:
    return {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
