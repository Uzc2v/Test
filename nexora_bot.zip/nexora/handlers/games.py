"""Mini o'yinlar menyusi (savollar handlers/quiz.py da)."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from keyboards import menus as kb
from utils import texts
from utils.helpers import show

router = Router(name="games")


@router.callback_query(F.data == "menu:game")
async def games_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, texts.GAMES_MENU, kb.games_menu())
