"""Eslatmalarni vaqti kelganda yuboruvchi fon jarayoni."""
from __future__ import annotations

import asyncio
import logging
import time

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError

from database.db import Database
from utils.timeutil import fmt_ts

log = logging.getLogger("nexora.scheduler")


async def reminder_loop(bot: Bot, db: Database, interval: int = 20) -> None:
    log.info("Eslatmalar rejalashtiruvchisi ishga tushdi")
    while True:
        try:
            for r in await db.due_reminders(int(time.time())):
                try:
                    await bot.send_message(
                        r["user_id"],
                        f"⏰ <b>ESLATMA</b>\n━━━━━━━━━━━━━━\n{_esc(r['text'])}\n\n"
                        f"<i>Belgilangan vaqt: {fmt_ts(r['remind_at'])}</i>",
                    )
                except TelegramForbiddenError:
                    log.info("Foydalanuvchi %s botni bloklagan", r["user_id"])
                except TelegramAPIError as e:
                    log.warning("Eslatma yuborilmadi (%s): %s", r["id"], e)
                await db.mark_reminder_sent(r["id"])
                await asyncio.sleep(0.05)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Eslatmalar siklida xato")
        await asyncio.sleep(interval)


def _esc(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
