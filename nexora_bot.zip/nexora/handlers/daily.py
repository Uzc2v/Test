"""Kundalik Yordamchi: eslatmalar, vazifalar, kunlik reja, shaxsiy statistika."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from database.db import Database
from handlers.profile import week_chart
from keyboards import menus as kb
from utils import texts
from utils.helpers import show
from utils.texts import esc
from utils.timeutil import fmt_ts, now_local, parse_reminder, today_str

router = Router(name="daily")


class DailyStates(StatesGroup):
    adding_task = State()
    adding_reminder = State()


async def _feature_ok(message: Message, db: Database, is_admin: bool) -> bool:
    if not is_admin and not await db.feature_on("daily"):
        await message.answer("🔒 Bu bo'lim vaqtincha o'chirilgan.", reply_markup=kb.only_home())
        return False
    return True


@router.callback_query(F.data == "menu:day")
async def daily_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, texts.DAILY_MENU, kb.daily_menu())


# ------------------------------------------------------------------ eslatmalar
async def _reminders_view(db: Database, uid: int):
    items = await db.list_reminders(uid)
    if items:
        lines = "\n".join(f"{i}. ⏰ <b>{fmt_ts(r['remind_at'])}</b> — {esc(r['text'])}" for i, r in enumerate(items, 1))
        body = lines + "\n\n<i>O'chirish uchun tugmani bosing 👇</i>"
    else:
        body = "<i>Faol eslatmalar yo'q.</i>"
    return f"{texts.BRAND}\n{texts.DIV}\n⏰ <b>Eslatmalar</b>\n\n{body}", kb.reminders_kb(items)


@router.callback_query(F.data == "day:rem")
async def reminders_list(cb: CallbackQuery, state: FSMContext, db: Database):
    await state.clear()
    text, markup = await _reminders_view(db, cb.from_user.id)
    await show(cb, text, markup)


@router.callback_query(F.data == "day:ra")
async def reminder_add_start(cb: CallbackQuery, state: FSMContext):
    await state.set_state(DailyStates.adding_reminder)
    await show(cb, texts.REMINDER_HELP, kb.to_daily())


@router.message(DailyStates.adding_reminder, F.text, ~F.text.startswith("/"))
async def reminder_add(message: Message, state: FSMContext, db: Database, is_admin: bool):
    if not await _feature_ok(message, db, is_admin):
        await state.clear()
        return
    parsed = parse_reminder(message.text)
    if not parsed:
        await message.answer(texts.REMINDER_BAD, reply_markup=kb.to_daily())
        return
    ts, body = parsed
    try:
        await db.add_reminder(message.from_user.id, body, ts)
    except ValueError:
        await state.clear()
        await message.answer("⚠️ Faol eslatmalar soni 30 tadan oshmasligi kerak. Avval ba'zilarini o'chiring.",
                             reply_markup=kb.to_daily())
        return
    await db.log(message.from_user.id, "reminder_add")
    await state.clear()
    text, markup = await _reminders_view(db, message.from_user.id)
    await message.answer(f"✅ Eslatma saqlandi: <b>{fmt_ts(ts)}</b>\n\n" + text, reply_markup=markup)


@router.callback_query(F.data.startswith("day:rd:"))
async def reminder_delete(cb: CallbackQuery, db: Database):
    rid = int(cb.data.split(":")[2])
    await db.delete_reminder(cb.from_user.id, rid)
    text, markup = await _reminders_view(db, cb.from_user.id)
    await show(cb, text, markup)


# --------------------------------------------------------- vazifalar va reja
def _plan_date(kind: str):
    return today_str() if kind == "p" else None


async def _tasks_view(db: Database, uid: int, kind: str):
    items = await db.list_tasks(uid, _plan_date(kind))
    total, done = await db.count_tasks(uid, _plan_date(kind))
    if kind == "p":
        title = f"🗓 <b>Bugungi reja</b> — {now_local().strftime('%d.%m.%Y')}"
        hint = "Bugun nimalarni qilmoqchisiz? Qo'shing va belgilab boring."
    else:
        title = "✅ <b>Vazifalar ro'yxati</b>"
        hint = "Vazifani bosing — bajarildi deb belgilanadi (+2 ball)."
    status = f"Bajarildi: <b>{done}/{total}</b>" if total else "<i>Ro'yxat bo'sh. ➕ tugmasi bilan qo'shing.</i>"
    return f"{texts.BRAND}\n{texts.DIV}\n{title}\n\n{status}\n<i>{hint}</i>", kb.tasks_kb(kind, items)


@router.callback_query(F.data.startswith("day:tasks:"))
async def tasks_list(cb: CallbackQuery, state: FSMContext, db: Database):
    await state.clear()
    kind = cb.data.split(":")[2]
    text, markup = await _tasks_view(db, cb.from_user.id, kind)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("day:ta:"))
async def task_add_start(cb: CallbackQuery, state: FSMContext):
    kind = cb.data.split(":")[2]
    await state.set_state(DailyStates.adding_task)
    await state.update_data(kind=kind)
    what = "reja bandini" if kind == "p" else "vazifani"
    await show(cb, f"➕ Yangi {what} yozing.\n<i>Bir nechta qo'shish uchun har birini yangi qatordan yozing (10 tagacha).</i>",
               kb.to_daily())


@router.message(DailyStates.adding_task, F.text, ~F.text.startswith("/"))
async def task_add(message: Message, state: FSMContext, db: Database, is_admin: bool):
    if not await _feature_ok(message, db, is_admin):
        await state.clear()
        return
    kind = (await state.get_data()).get("kind", "t")
    lines = [ln.strip()[:150] for ln in message.text.splitlines() if ln.strip()][:10]
    if not lines:
        await message.answer("⚠️ Matn bo'sh. Qaytadan yozing.")
        return
    uid = message.from_user.id
    total, _ = await db.count_tasks(uid, _plan_date(kind))
    if total + len(lines) > 50:
        await message.answer("⚠️ Ro'yxatda 50 tadan ortiq band bo'lishi mumkin emas. Avval bajarilganlarini tozalang.",
                             reply_markup=kb.to_daily())
        return
    for ln in lines:
        await db.add_task(uid, ln, _plan_date(kind))
        await db.log(uid, "task_add")
    await state.clear()
    text, markup = await _tasks_view(db, uid, kind)
    await message.answer(f"✅ Qo'shildi: {len(lines)} ta\n\n" + text, reply_markup=markup)


@router.callback_query(F.data.startswith("day:tt:"))
async def task_toggle(cb: CallbackQuery, db: Database):
    _, _, kind, tid = cb.data.split(":")
    uid = cb.from_user.id
    res = await db.toggle_task(uid, int(tid))
    if res and res[1]:
        await db.add_points(uid, 2)
        await db.log(uid, "task_done")
        await cb.answer("🎉 +2 ball!")
        text, markup = await _tasks_view(db, uid, kind)
        await show(cb, text, markup, ack=False)
        return
    text, markup = await _tasks_view(db, uid, kind)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("day:td:"))
async def task_delete(cb: CallbackQuery, db: Database):
    _, _, kind, tid = cb.data.split(":")
    await db.delete_task(cb.from_user.id, int(tid))
    text, markup = await _tasks_view(db, cb.from_user.id, kind)
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("day:tc:"))
async def task_clear(cb: CallbackQuery, db: Database):
    kind = cb.data.split(":")[2]
    await db.clear_done_tasks(cb.from_user.id, _plan_date(kind))
    text, markup = await _tasks_view(db, cb.from_user.id, kind)
    await show(cb, text, markup)


# ----------------------------------------------------------------- statistika
@router.callback_query(F.data == "day:stats")
async def daily_stats(cb: CallbackQuery, state: FSMContext, db: Database):
    await state.clear()
    uid = cb.from_user.id
    t_total, t_done = await db.count_tasks(uid, None)
    p_total, p_done = await db.count_tasks(uid, today_str())
    rem = await db.count_reminders(uid)
    user = await db.get_user(uid)
    text = (
        f"{texts.BRAND}\n{texts.DIV}\n📊 <b>Shaxsiy statistika</b>\n\n"
        f"✅ Vazifalar: <b>{t_done}/{t_total}</b> bajarilgan\n"
        f"🗓 Bugungi reja: <b>{p_done}/{p_total}</b> bajarilgan\n"
        f"⏰ Faol eslatmalar: <b>{rem}</b>\n"
        f"⭐ Ballar: <b>{user['points'] if user else 0}</b>\n\n"
        f"📈 <b>So'nggi 7 kun faolligi</b>\n{await week_chart(db, uid)}"
    )
    await show(cb, text, kb.to_daily())
