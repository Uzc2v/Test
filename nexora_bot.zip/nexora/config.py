"""NEXORA konfiguratsiyasi.

Barcha sirli ma'lumotlar (token, API kalitlar) faqat .env faylidan o'qiladi.
Kod ichida hech qanday token yozilmagan.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _int_set(raw: str) -> frozenset[int]:
    result: set[int] = set()
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if part.isdigit():
            result.add(int(part))
    return frozenset(result)


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)).strip())
    except ValueError:
        return default


@dataclass(frozen=True)
class Config:
    bot_token: str
    admin_ids: frozenset[int]
    db_path: Path
    tz_offset_hours: int
    log_level: str
    ai_api_key: str
    ai_base_url: str
    ai_model: str
    ai_daily_limit: int
    image_base_url: str
    image_api_key: str

    @property
    def ai_enabled(self) -> bool:
        return bool(self.ai_api_key)

    @property
    def secrets(self) -> list[str]:
        """Loglarda yashirilishi kerak bo'lgan qiymatlar."""
        return [s for s in (self.bot_token, self.ai_api_key, self.image_api_key) if s]


def load_config() -> Config:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token or ":" not in token:
        print(
            "\n❌ XATO: BOT_TOKEN topilmadi.\n"
            "   1) .env.example faylini .env nomi bilan nusxalang\n"
            "   2) @BotFather'dan olingan tokenni .env ichiga BOT_TOKEN= dan keyin yozing\n"
        )
        sys.exit(1)

    db_path = Path(os.getenv("DB_PATH", "data/nexora.db").strip())
    if not db_path.is_absolute():
        db_path = BASE_DIR / db_path

    return Config(
        bot_token=token,
        admin_ids=_int_set(os.getenv("ADMIN_IDS", "")),
        db_path=db_path,
        tz_offset_hours=_int("TZ_OFFSET_HOURS", 5),
        log_level=os.getenv("LOG_LEVEL", "INFO").strip().upper(),
        ai_api_key=os.getenv("AI_API_KEY", "").strip(),
        ai_base_url=os.getenv("AI_BASE_URL", "https://api.groq.com/openai/v1").strip().rstrip("/"),
        ai_model=os.getenv("AI_MODEL", "llama-3.3-70b-versatile").strip(),
        ai_daily_limit=_int("AI_DAILY_LIMIT", 40),
        image_base_url=os.getenv("IMAGE_BASE_URL", "https://image.pollinations.ai").strip().rstrip("/"),
        image_api_key=os.getenv("IMAGE_API_KEY", "").strip(),
    )
