"""Ta'lim Markazi: lug'at kartochkalari va kunlik bilim sinovi."""
import random

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery

from database.db import Database
from keyboards import menus as kb
from services import content
from utils import texts
from utils.helpers import show
from utils.timeutil import today_str

router = Router(name="education")


@router.callback_query(F.data == "menu:edu")
async def edu_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, texts.EDU_MENU, kb.edu_menu())


@router.callback_query(F.data == "edu:vocab")
async def vocab_card(cb: CallbackQuery, db: Database):
    en, uz, ex_en, ex_uz = random.choice(content.VOCAB)
    await db.log(cb.from_user.id, "vocab")
    text = (
        f"{texts.BRAND}\n{texts.DIV}\n📖 <b>Lug'at kartochkasi</b>\n\n"
        f"🇬🇧 <b>{texts.esc(en)}</b>\n🇺🇿 <b>{texts.esc(uz)}</b>\n\n"
        f"💬 <i>{texts.esc(ex_en)}</i>\n<i>{texts.esc(ex_uz)}</i>"
    )
    await show(cb, text, kb.vocab_card())


# --------------------------------------------------------------- kunlik sinov
def _render_daily(day: str, step: int, prefix: str = ""):
    kind, qid = content.daily_questions(day)[step]
    q = content.get_question(kind, qid)
    head = f"{texts.BRAND}\n{texts.DIV}\n📆 <b>Kunlik bilim sinovi</b> — {step + 1}/{content.DAILY_COUNT}\n\n"
    text = (prefix + "\n\n" if prefix else "") + head + f"❓ <b>{texts.esc(q.text)}</b>"
    return text, kb.daily_question_kb(step, q.options)


def _daily_summary(score: int, prefix: str = "") -> str:
    total = content.DAILY_COUNT
    stars = "⭐" * score + "▫️" * (total - score)
    verdict = ("🔥 Ajoyib natija!" if score == total else
               "👏 Yaxshi!" if score >= 3 else "💪 Harakatni davom ettiring!")
    return (
        (prefix + "\n\n" if prefix else "") +
        f"{texts.BRAND}\n{texts.DIV}\n📆 <b>Kunlik sinov yakunlandi</b>\n\n"
        f"{stars}\nNatija: <b>{score}/{total}</b>\n{verdict}\n\n"
        "Yangi sinov ertaga ochiladi 🌙"
    )


@router.callback_query(F.data == "edu:daily")
async def daily_start(cb: CallbackQuery, db: Database):
    day = today_str()
    prog = await db.get_daily(cb.from_user.id, day)
    if prog["step"] >= content.DAILY_COUNT:
        await show(cb, _daily_summary(prog["score"]), kb.edu_menu())
        return
    text, markup = _render_daily(day, prog["step"])
    await show(cb, text, markup)


@router.callback_query(F.data.startswith("dq:a:"))
async def daily_answer(cb: CallbackQuery, db: Database):
    uid = cb.from_user.id
    try:
        _, _, step_s, choice_s = cb.data.split(":")
        step, choice = int(step_s), int(choice_s)
    except ValueError:
        await cb.answer()
        return
    day = today_str()
    prog = await db.get_daily(uid, day)
    if step != prog["step"] or prog["step"] >= content.DAILY_COUNT:
        await daily_start(cb, db)  # eski tugma bosildi — joriy holatni ko'rsatamiz
        return

    kind, qid = content.daily_questions(day)[step]
    q = content.get_question(kind, qid)
    correct = choice == q.answer
    score = prog["score"] + (1 if correct else 0)
    new_step = step + 1
    await db.set_daily(uid, day, new_step, score)
    if correct:
        await db.add_points(uid, 10)
        prefix = "✅ <b>To'g'ri!</b> +10 ball"
    else:
        prefix = f"❌ <b>Noto'g'ri.</b> To'g'ri javob: <b>{texts.esc(q.options[q.answer])}</b>"

    if new_step >= content.DAILY_COUNT:
        await db.add_points(uid, 10)
        await db.log(uid, "daily_quiz")
        await show(cb, _daily_summary(score, prefix + "\n🎁 Yakunlash bonusi: +10 ball"), kb.edu_menu())
    else:
        text, markup = _render_daily(day, new_step, prefix)
        await show(cb, text, markup)
