"""Rasm yaratish xizmati (standart: Pollinations — kalit shart emas)."""
from __future__ import annotations

import asyncio
import logging
import random
from urllib.parse import quote

import aiohttp

from config import Config

log = logging.getLogger("nexora.images")


class ImageError(Exception):
    def __init__(self, user_message: str):
        super().__init__(user_message)
        self.user_message = user_message


class ImageService:
    def __init__(self, config: Config):
        self.cfg = config
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120))
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def generate(self, prompt: str, width: int = 1024, height: int = 1024) -> bytes:
        prompt = prompt.strip()[:600]
        url = f"{self.cfg.image_base_url}/prompt/{quote(prompt, safe='')}"
        params = {
            "width": width, "height": height, "nologo": "true",
            "seed": random.randint(1, 10_000_000),
        }
        headers = {}
        if self.cfg.image_api_key:
            headers["Authorization"] = f"Bearer {self.cfg.image_api_key}"

        session = await self._get_session()
        error = "Rasm yaratish xizmati hozir javob bermadi. Birozdan so'ng qayta urinib ko'ring."
        for attempt in range(2):
            try:
                async with session.get(url, params=params, headers=headers) as resp:
                    ctype = resp.headers.get("Content-Type", "")
                    if resp.status == 200 and ctype.startswith("image/"):
                        data = await resp.read()
                        if len(data) > 1000:
                            return data
                    log.warning("Rasm xizmati HTTP %s (%s)", resp.status, ctype)
                    if resp.status in (401, 403):
                        raise ImageError("Rasm xizmati kalit talab qilmoqda. Administrator IMAGE_API_KEY ni kiritishi kerak.")
                    if resp.status == 429:
                        raise ImageError("Rasm xizmatida so'rovlar ko'p. Bir daqiqadan so'ng urinib ko'ring.")
            except ImageError:
                raise
            except asyncio.TimeoutError:
                error = "Rasm yaratish uzoq cho'zildi. Qayta urinib ko'ring."
            except aiohttp.ClientError as e:
                log.warning("Rasm tarmoq xatosi: %s", e)
                error = "Rasm xizmatiga ulanib bo'lmadi. Internet aloqasini tekshiring."
            if attempt == 0:
                await asyncio.sleep(2)
        raise ImageError(error)
