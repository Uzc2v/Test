"""Profil va reyting jadvali."""
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from database.db import Database
from keyboards import menus as kb
from utils import texts
from utils.helpers import show
from utils.texts import esc
from utils.timeutil import fmt_date, fmt_ts, last_days, local_date, now_ts, WEEKDAYS_UZ

router = Router(name="profile")


async def week_chart(db: Database, uid: int) -> str:
    days = last_days(7)
    since = now_ts() - 8 * 86400
    times = await db.activity_times(uid, since)
    counts = {d: 0 for d in days}
    for ts in times:
        d = local_date(ts)
        if d in counts:
            counts[d] += 1
    mx = max(counts.values()) if counts else 0
    lines = [f"<code>{WEEKDAYS_UZ[d.weekday()]:<4}</code> {texts.bar(counts[d], mx)} {counts[d]}" for d in days]
    return "\n".join(lines)


async def build_profile(db: Database, uid: int) -> str:
    user = await db.get_user(uid)
    if not user:
        return "Profil topilmadi. /start yuboring."
    rank = await db.user_rank(uid)
    counts = await db.activity_counts(uid)
    total_actions = sum(counts.values())
    ai_total = sum(v for k, v in counts.items() if k.startswith("ai_"))
    quiz_ok = counts.get("quiz_ok", 0)
    quiz_all = quiz_ok + counts.get("quiz_bad", 0)
    creative = sum(counts.get(k, 0) for k in ("image", "imgprompt", "story", "poem", "script", "vprompt"))
    recent = await db.recent_activity(uid, 6)
    history = "\n".join(
        f"• {texts.ACTION_LABELS.get(r['action'], r['action'])} — <i>{fmt_ts(r['created_at'])}</i>" for r in recent
    ) or "<i>Hozircha bo'sh</i>"
    uname = f"@{esc(user['username'])}" if user["username"] else "—"
    return (
        f"{texts.BRAND}\n{texts.DIV}\n👤 <b>Profilim</b>\n\n"
        f"🆔 Telegram ID: <code>{uid}</code>\n"
        f"📛 Ism: <b>{esc(user['full_name'])}</b>\n"
        f"🔗 Username: {uname}\n"
        f"📅 Ro'yxatdan o'tgan: {fmt_date(user['joined_at'])}\n\n"
        f"⭐ Ballar: <b>{user['points']}</b>\n"
        f"🏆 Reytingdagi o'rni: <b>{rank if rank else '—'}</b>\n\n"
        f"📈 <b>Faollik</b>\n"
        f"• Jami amallar: {total_actions}\n"
        f"• AI so'rovlar: {ai_total}\n"
        f"• Ijodiy ishlar: {creative}\n"
        f"• Testlarda to'g'ri javoblar: {quiz_ok}/{quiz_all}\n\n"
        f"🗓 <b>So'nggi 7 kun</b>\n{await week_chart(db, uid)}\n\n"
        f"🕘 <b>Foydalanish tarixi</b>\n{history}"
    )


async def build_top(db: Database, uid: int) -> str:
    top = await db.leaderboard(10)
    if not top:
        body = "<i>Hali hech kim ball to'plamagan. Birinchi bo'ling! 🎮</i>"
    else:
        body = "\n".join(
            f"{texts.rank_medal(i)} {esc(u['full_name'][:22] or 'Nomaʼlum')} — <b>{u['points']}</b>"
            for i, u in enumerate(top, 1)
        )
    rank = await db.user_rank(uid)
    me = await db.get_user(uid)
    mine = f"\n\n📍 Sizning o'rningiz: <b>{rank}</b> ({me['points']} ball)" if rank and me else \
        "\n\n📍 Reytingga kirish uchun o'yin yoki test yeching!"
    return f"{texts.BRAND}\n{texts.DIV}\n🏆 <b>Reyting jadvali — TOP 10</b>\n\n{body}{mine}"


@router.message(Command("profile"))
async def cmd_profile(message: Message, state: FSMContext, db: Database):
    await state.clear()
    await message.answer(await build_profile(db, message.from_user.id), reply_markup=kb.profile_kb())


@router.callback_query(F.data == "menu:prof")
async def cb_profile(cb: CallbackQuery, state: FSMContext, db: Database):
    await state.clear()
    await show(cb, await build_profile(db, cb.from_user.id), kb.profile_kb())


@router.message(Command("top"))
async def cmd_top(message: Message, state: FSMContext, db: Database):
    await state.clear()
    await message.answer(await build_top(db, message.from_user.id), reply_markup=kb.top_kb())


@router.callback_query(F.data == "menu:top")
async def cb_top(cb: CallbackQuery, state: FSMContext, db: Database):
    await state.clear()
    await show(cb, await build_top(db, cb.from_user.id), kb.top_kb())
