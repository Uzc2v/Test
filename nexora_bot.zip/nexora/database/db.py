"""SQLite bazasi (stdlib sqlite3, asyncio.to_thread orqali asinxron).

Barcha so'rovlar shu bitta klassda — keyinchalik PostgreSQL'ga o'tish uchun
faqat shu klassni (asyncpg bilan) qayta yozish kifoya: handlerlar o'zgarmaydi.
"""
from __future__ import annotations

import asyncio
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Callable

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id           INTEGER PRIMARY KEY,
    full_name    TEXT    NOT NULL DEFAULT '',
    username     TEXT,
    joined_at    INTEGER NOT NULL,
    last_active  INTEGER NOT NULL,
    points       INTEGER NOT NULL DEFAULT 0,
    is_banned    INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    mode       TEXT    NOT NULL,
    role       TEXT    NOT NULL,
    content    TEXT    NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_user ON messages(user_id, mode, id);
CREATE TABLE IF NOT EXISTS activity (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    action     TEXT    NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_activity_user ON activity(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_activity_time ON activity(created_at);
CREATE TABLE IF NOT EXISTS tasks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    title      TEXT    NOT NULL,
    done       INTEGER NOT NULL DEFAULT 0,
    rewarded   INTEGER NOT NULL DEFAULT 0,
    plan_date  TEXT,
    created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id, plan_date);
CREATE TABLE IF NOT EXISTS reminders (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    text       TEXT    NOT NULL,
    remind_at  INTEGER NOT NULL,
    sent       INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_reminders_due ON reminders(sent, remind_at);
CREATE TABLE IF NOT EXISTS answered (
    user_id INTEGER NOT NULL,
    key     TEXT    NOT NULL,
    day     TEXT    NOT NULL,
    PRIMARY KEY (user_id, key, day)
);
CREATE TABLE IF NOT EXISTS daily_quiz (
    user_id INTEGER NOT NULL,
    day     TEXT    NOT NULL,
    step    INTEGER NOT NULL DEFAULT 0,
    score   INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, day)
);
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


class Database:
    def __init__(self, path: Path | str):
        self.path = str(path)
        self._lock = threading.Lock()
        self._conn: sqlite3.Connection | None = None

    # ------------------------------------------------------------ yadro
    async def connect(self) -> None:
        await asyncio.to_thread(self._connect)

    def _connect(self) -> None:
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.executescript(SCHEMA)
        conn.commit()
        self._conn = conn

    async def close(self) -> None:
        def _close():
            with self._lock:
                if self._conn:
                    self._conn.close()
                    self._conn = None
        await asyncio.to_thread(_close)

    async def _run(self, fn: Callable[[sqlite3.Connection], Any]) -> Any:
        def wrapper():
            with self._lock:
                assert self._conn is not None, "Baza ulanmagan"
                try:
                    result = fn(self._conn)
                    self._conn.commit()
                    return result
                except Exception:
                    self._conn.rollback()
                    raise
        return await asyncio.to_thread(wrapper)

    async def _exec(self, sql: str, params: tuple = ()) -> int:
        return await self._run(lambda c: c.execute(sql, params).rowcount)

    async def _one(self, sql: str, params: tuple = ()) -> dict | None:
        def fn(c):
            row = c.execute(sql, params).fetchone()
            return dict(row) if row else None
        return await self._run(fn)

    async def _all(self, sql: str, params: tuple = ()) -> list[dict]:
        return await self._run(lambda c: [dict(r) for r in c.execute(sql, params).fetchall()])

    async def _val(self, sql: str, params: tuple = (), default: Any = 0) -> Any:
        row = await self._run(lambda c: c.execute(sql, params).fetchone())
        return row[0] if row and row[0] is not None else default

    # ------------------------------------------------------ foydalanuvchilar
    async def upsert_user(self, uid: int, full_name: str, username: str | None) -> bool:
        """Foydalanuvchini yaratadi/yangilaydi. Yangi bo'lsa True qaytaradi."""
        now = int(time.time())

        def fn(c):
            cur = c.execute(
                "INSERT OR IGNORE INTO users(id, full_name, username, joined_at, last_active) "
                "VALUES (?,?,?,?,?)",
                (uid, full_name, username, now, now),
            )
            if cur.rowcount == 1:
                return True
            c.execute(
                "UPDATE users SET full_name=?, username=?, last_active=? WHERE id=?",
                (full_name, username, now, uid),
            )
            return False
        return await self._run(fn)

    async def get_user(self, uid: int) -> dict | None:
        return await self._one("SELECT * FROM users WHERE id=?", (uid,))

    async def is_banned(self, uid: int) -> bool:
        return bool(await self._val("SELECT is_banned FROM users WHERE id=?", (uid,), 0))

    async def set_banned(self, uid: int, banned: bool) -> int:
        return await self._exec("UPDATE users SET is_banned=? WHERE id=?", (int(banned), uid))

    async def add_points(self, uid: int, amount: int) -> None:
        await self._exec("UPDATE users SET points = MAX(0, points + ?) WHERE id=?", (amount, uid))

    async def leaderboard(self, limit: int = 10) -> list[dict]:
        return await self._all(
            "SELECT id, full_name, points FROM users WHERE is_banned=0 AND points>0 "
            "ORDER BY points DESC, id ASC LIMIT ?", (limit,))

    async def user_rank(self, uid: int) -> int | None:
        user = await self.get_user(uid)
        if not user or user["points"] <= 0:
            return None
        better = await self._val(
            "SELECT COUNT(*) FROM users WHERE is_banned=0 AND (points > ? OR (points = ? AND id < ?))",
            (user["points"], user["points"], uid))
        return better + 1

    # ------------------------------------------------------------ faollik
    async def log(self, uid: int, action: str) -> None:
        await self._exec(
            "INSERT INTO activity(user_id, action, created_at) VALUES (?,?,?)",
            (uid, action, int(time.time())))

    async def count_activity(self, uid: int, action: str, since: int = 0) -> int:
        return await self._val(
            "SELECT COUNT(*) FROM activity WHERE user_id=? AND action=? AND created_at>=?",
            (uid, action, since))

    async def activity_counts(self, uid: int) -> dict[str, int]:
        rows = await self._all(
            "SELECT action, COUNT(*) AS n FROM activity WHERE user_id=? AND action!='api' GROUP BY action",
            (uid,))
        return {r["action"]: r["n"] for r in rows}

    async def recent_activity(self, uid: int, limit: int = 8) -> list[dict]:
        return await self._all(
            "SELECT action, created_at FROM activity WHERE user_id=? AND action!='api' "
            "ORDER BY id DESC LIMIT ?", (uid, limit))

    async def activity_times(self, uid: int, since: int) -> list[int]:
        rows = await self._all(
            "SELECT created_at FROM activity WHERE user_id=? AND action!='api' AND created_at>=?",
            (uid, since))
        return [r["created_at"] for r in rows]

    # ------------------------------------------------------- AI suhbat tarixi
    async def save_message(self, uid: int, mode: str, role: str, content: str) -> None:
        def fn(c):
            c.execute(
                "INSERT INTO messages(user_id, mode, role, content, created_at) VALUES (?,?,?,?,?)",
                (uid, mode, role, content[:6000], int(time.time())))
            c.execute(
                "DELETE FROM messages WHERE user_id=? AND mode=? AND id NOT IN "
                "(SELECT id FROM messages WHERE user_id=? AND mode=? ORDER BY id DESC LIMIT 100)",
                (uid, mode, uid, mode))
        await self._run(fn)

    async def get_history(self, uid: int, mode: str, limit: int = 10) -> list[dict]:
        return await self._all(
            "SELECT role, content FROM (SELECT id, role, content FROM messages "
            "WHERE user_id=? AND mode=? ORDER BY id DESC LIMIT ?) ORDER BY id",
            (uid, mode, limit))

    async def clear_history(self, uid: int, mode: str | None = None) -> int:
        if mode:
            return await self._exec("DELETE FROM messages WHERE user_id=? AND mode=?", (uid, mode))
        return await self._exec("DELETE FROM messages WHERE user_id=?", (uid,))

    # ----------------------------------------------------------- vazifalar
    async def add_task(self, uid: int, title: str, plan_date: str | None = None) -> None:
        await self._exec(
            "INSERT INTO tasks(user_id, title, plan_date, created_at) VALUES (?,?,?,?)",
            (uid, title, plan_date, int(time.time())))

    async def list_tasks(self, uid: int, plan_date: str | None, limit: int = 15) -> list[dict]:
        return await self._all(
            "SELECT * FROM tasks WHERE user_id=? AND plan_date IS ? ORDER BY done, id LIMIT ?",
            (uid, plan_date, limit))

    async def count_tasks(self, uid: int, plan_date: str | None) -> tuple[int, int]:
        row = await self._one(
            "SELECT COUNT(*) AS total, COALESCE(SUM(done),0) AS done FROM tasks "
            "WHERE user_id=? AND plan_date IS ?", (uid, plan_date))
        return (row["total"], row["done"]) if row else (0, 0)

    async def toggle_task(self, uid: int, task_id: int) -> tuple[bool, bool] | None:
        """(yangi_holat_bajarilgan, birinchi_marta_mukofot) yoki None."""
        def fn(c):
            row = c.execute("SELECT done, rewarded FROM tasks WHERE id=? AND user_id=?",
                            (task_id, uid)).fetchone()
            if not row:
                return None
            new_done = 0 if row["done"] else 1
            reward = bool(new_done and not row["rewarded"])
            c.execute("UPDATE tasks SET done=?, rewarded=? WHERE id=?",
                      (new_done, 1 if (row["rewarded"] or reward) else 0, task_id))
            return bool(new_done), reward
        return await self._run(fn)

    async def delete_task(self, uid: int, task_id: int) -> None:
        await self._exec("DELETE FROM tasks WHERE id=? AND user_id=?", (task_id, uid))

    async def clear_done_tasks(self, uid: int, plan_date: str | None) -> None:
        await self._exec("DELETE FROM tasks WHERE user_id=? AND plan_date IS ? AND done=1",
                         (uid, plan_date))

    # ----------------------------------------------------------- eslatmalar
    async def add_reminder(self, uid: int, text: str, remind_at: int) -> None:
        count = await self._val("SELECT COUNT(*) FROM reminders WHERE user_id=? AND sent=0", (uid,))
        if count >= 30:
            raise ValueError("limit")
        await self._exec("INSERT INTO reminders(user_id, text, remind_at) VALUES (?,?,?)",
                         (uid, text, remind_at))

    async def list_reminders(self, uid: int, limit: int = 10) -> list[dict]:
        return await self._all(
            "SELECT * FROM reminders WHERE user_id=? AND sent=0 ORDER BY remind_at LIMIT ?",
            (uid, limit))

    async def count_reminders(self, uid: int) -> int:
        return await self._val("SELECT COUNT(*) FROM reminders WHERE user_id=? AND sent=0", (uid,))

    async def delete_reminder(self, uid: int, rid: int) -> None:
        await self._exec("DELETE FROM reminders WHERE id=? AND user_id=?", (rid, uid))

    async def due_reminders(self, now: int, limit: int = 50) -> list[dict]:
        return await self._all(
            "SELECT * FROM reminders WHERE sent=0 AND remind_at<=? ORDER BY remind_at LIMIT ?",
            (now, limit))

    async def mark_reminder_sent(self, rid: int) -> None:
        await self._exec("UPDATE reminders SET sent=1 WHERE id=?", (rid,))

    # ------------------------------------------------------ o'yin/viktorina
    async def mark_answered(self, uid: int, key: str, day: str) -> bool:
        """Shu savolga bugun birinchi marta javob berilgan bo'lsa True."""
        return await self._exec(
            "INSERT OR IGNORE INTO answered(user_id, key, day) VALUES (?,?,?)",
            (uid, key, day)) == 1

    async def get_daily(self, uid: int, day: str) -> dict:
        row = await self._one("SELECT step, score FROM daily_quiz WHERE user_id=? AND day=?", (uid, day))
        return row or {"step": 0, "score": 0}

    async def set_daily(self, uid: int, day: str, step: int, score: int) -> None:
        await self._exec(
            "INSERT OR REPLACE INTO daily_quiz(user_id, day, step, score) VALUES (?,?,?,?)",
            (uid, day, step, score))

    # ------------------------------------------------------------- sozlamalar
    async def feature_on(self, name: str) -> bool:
        row = await self._one("SELECT value FROM settings WHERE key=?", (f"feature_{name}",))
        return row is None or row["value"] == "1"

    async def set_feature(self, name: str, on: bool) -> None:
        await self._exec("INSERT OR REPLACE INTO settings(key, value) VALUES (?,?)",
                         (f"feature_{name}", "1" if on else "0"))

    # ------------------------------------------------------------- admin
    async def stats(self) -> dict:
        now = int(time.time())
        day_start = now - (now % 86400)
        return {
            "total": await self._val("SELECT COUNT(*) FROM users"),
            "banned": await self._val("SELECT COUNT(*) FROM users WHERE is_banned=1"),
            "active_24h": await self._val("SELECT COUNT(*) FROM users WHERE last_active>=?", (now - 86400,)),
            "active_7d": await self._val("SELECT COUNT(*) FROM users WHERE last_active>=?", (now - 7 * 86400,)),
            "new_today": await self._val("SELECT COUNT(*) FROM users WHERE joined_at>=?", (day_start,)),
            "new_7d": await self._val("SELECT COUNT(*) FROM users WHERE joined_at>=?", (now - 7 * 86400,)),
            "points": await self._val("SELECT COALESCE(SUM(points),0) FROM users"),
            "api_today": await self._val("SELECT COUNT(*) FROM activity WHERE action='api' AND created_at>=?", (now - 86400,)),
            "actions_total": await self._val("SELECT COUNT(*) FROM activity WHERE action!='api'"),
            "tasks": await self._val("SELECT COUNT(*) FROM tasks"),
            "reminders": await self._val("SELECT COUNT(*) FROM reminders WHERE sent=0"),
        }

    async def top_actions(self, limit: int = 6) -> list[dict]:
        return await self._all(
            "SELECT action, COUNT(*) AS n FROM activity WHERE action!='api' "
            "GROUP BY action ORDER BY n DESC LIMIT ?", (limit,))

    async def recent_users(self, limit: int = 10) -> list[dict]:
        return await self._all("SELECT * FROM users ORDER BY joined_at DESC, id DESC LIMIT ?", (limit,))

    async def all_user_ids(self) -> list[int]:
        rows = await self._all("SELECT id FROM users WHERE is_banned=0")
        return [r["id"] for r in rows]
