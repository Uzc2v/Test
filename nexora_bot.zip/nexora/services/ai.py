"""AI xizmati: OpenAI formatiga mos istalgan provayder (Groq, OpenAI, OpenRouter, Gemini...)."""
from __future__ import annotations

import asyncio
import logging

import aiohttp

from config import Config

log = logging.getLogger("nexora.ai")

LANG_RULE = (
    "Foydalanuvchi qaysi tilda yozsa, o'sha tilda javob ber; til aniq bo'lmasa o'zbek tilida javob ber. "
    "Javobing aniq, foydali va ixcham bo'lsin. Telegram uchun juda uzun javob yozma."
)

SYSTEM_PROMPTS = {
    "chat": (
        "Sen NEXORA — Telegram'dagi aqlli, do'stona va professional yordamchisan. "
        "Savollarga javob ber, tushuntir, maslahat ber. " + LANG_RULE
    ),
    "translate": (
        "Sen professional tarjimonsan. Foydalanuvchi matnini tarjima qil: agar matn o'zbek tilida bo'lsa — "
        "inglizchaga, boshqa tilda bo'lsa — o'zbekchaga. Foydalanuvchi aniq til so'ragan bo'lsa (masalan "
        "«ruscha: ...»), o'sha tilga tarjima qil. Faqat tarjimani yoz, ortiqcha izoh bermasdan."
    ),
    "code": (
        "Sen tajribali dasturchisan. Kod yozish, xatolarni topish va tushuntirishda yordam ber. "
        "Kodni aniq va ishlaydigan holatda ber, qisqa izoh qo'sh. Tushuntirishlar o'zbek tilida bo'lsin."
    ),
    "edit": (
        "Sen muharrir va korrektorsan. Foydalanuvchi matnini yaxshila: imlo va uslub xatolarini to'g'irla, "
        "ravon qil, ma'noni saqlab qol. Avval tahrirlangan matnni ber, so'ng nimalar o'zgargani haqida "
        "1-3 qisqa band yoz. Foydalanuvchi matn tilida javob ber."
    ),
    "tutor": (
        "Sen ingliz tili o'qituvchisisan. Foydalanuvchi o'zbek tilida so'raydi. Grammatika, so'z, talaffuz "
        "va misollarni sodda tushuntir: qoidani o'zbekcha ayt, misollarni inglizcha + o'zbekcha tarjimasi bilan ber. "
        "Foydalanuvchi xato qilsa, muloyimlik bilan tuzat."
    ),
    "story": (
        "Sen mohir hikoyanavissan. Berilgan mavzuda qiziqarli, to'liq, boshlanishi-rivoji-yakunli qisqa hikoya yoz "
        "(taxminan 250-400 so'z). Til: foydalanuvchi so'ragan til, aks holda o'zbek tili. Sarlavha qo'y."
    ),
    "poem": (
        "Sen shoirsan. Berilgan mavzuda original she'r yoz (3-5 band, qofiyali, mazmunli). Til: foydalanuvchi "
        "so'ragan til, aks holda o'zbek tili. Sarlavha qo'y. Mavjud mashhur she'rlarni ko'chirma."
    ),
    "script": (
        "Sen kino/video ssenariychisisan. Berilgan g'oya bo'yicha qisqa video uchun ssenariy yoz: sarlavha, "
        "davomiyligi, sahnalar (har sahnada: ko'rinish, harakat, dialog/ovoz, taxminiy vaqt). "
        "O'zbek tilida yoz."
    ),
    "vprompt": (
        "Sen AI-video generatorlar (Runway, Kling, Sora, Veo va boshqalar) uchun prompt muhandisisan. "
        "Foydalanuvchi g'oyasi asosida 3 ta turli uslubdagi batafsil INGLIZCHA video prompt yoz "
        "(kamera harakati, yorug'lik, muhit, uslub, davomiylik). Har bir prompt ostiga 1 qatorli o'zbekcha izoh qo'sh."
    ),
    "imgprompt": (
        "Sen AI-rasm generatorlar (Midjourney, DALL-E, Stable Diffusion, Flux) uchun prompt muhandisisan. "
        "Foydalanuvchi g'oyasi asosida 3 ta turli uslubdagi batafsil INGLIZCHA rasm prompti yoz "
        "(obyekt, muhit, yorug'lik, kompozitsiya, uslub, sifat kalit so'zlari). "
        "Har bir prompt ostiga 1 qatorli o'zbekcha izoh qo'sh."
    ),
    "enhance": (
        "Rewrite the user's idea as ONE vivid, detailed English image-generation prompt (max 60 words). "
        "Output only the prompt text, nothing else."
    ),
}


class AIError(Exception):
    """Foydalanuvchiga ko'rsatish mumkin bo'lgan tushunarli xato."""

    def __init__(self, user_message: str):
        super().__init__(user_message)
        self.user_message = user_message


class AIService:
    def __init__(self, config: Config):
        self.cfg = config
        self._session: aiohttp.ClientSession | None = None

    @property
    def enabled(self) -> bool:
        return self.cfg.ai_enabled

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60))
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def chat(self, messages: list[dict], temperature: float = 0.7, max_tokens: int = 1500) -> str:
        if not self.enabled:
            raise AIError("AI xizmati sozlanmagan. Administrator .env faylida AI_API_KEY ni kiritishi kerak.")

        url = f"{self.cfg.ai_base_url}/chat/completions"
        headers = {"Authorization": f"Bearer {self.cfg.ai_api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.cfg.ai_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        session = await self._get_session()
        last_error = "AI xizmati hozir javob bermadi. Birozdan so'ng qayta urinib ko'ring."

        for attempt in range(2):
            try:
                async with session.post(url, json=payload, headers=headers) as resp:
                    if resp.status == 200:
                        data = await resp.json(content_type=None)
                        try:
                            text = data["choices"][0]["message"]["content"]
                        except (KeyError, IndexError, TypeError):
                            log.error("AI kutilmagan javob formati: %s", str(data)[:300])
                            raise AIError("AI xizmatidan noto'g'ri javob keldi. Qayta urinib ko'ring.")
                        text = (text or "").strip()
                        if not text:
                            raise AIError("AI bo'sh javob qaytardi. Savolni boshqacha yozib ko'ring.")
                        return text
                    body = (await resp.text())[:300]
                    log.warning("AI HTTP %s: %s", resp.status, body)
                    if resp.status in (401, 403):
                        raise AIError("AI xizmati kaliti noto'g'ri yoki ruxsat yo'q. Administratorga xabar bering.")
                    if resp.status == 404:
                        raise AIError("AI modeli topilmadi. Administrator AI_MODEL sozlamasini tekshirishi kerak.")
                    if resp.status == 429:
                        raise AIError("AI xizmatida so'rovlar limiti tugadi. Birozdan so'ng urinib ko'ring.")
                    if resp.status == 400:
                        raise AIError("So'rov AI xizmati tomonidan qabul qilinmadi. Matnni qisqartirib ko'ring.")
                    last_error = f"AI xizmatida vaqtinchalik nosozlik ({resp.status})."
            except AIError:
                raise
            except asyncio.TimeoutError:
                last_error = "AI xizmati juda sekin javob berdi. Qayta urinib ko'ring."
            except aiohttp.ClientError as e:
                log.warning("AI tarmoq xatosi: %s", e)
                last_error = "AI xizmatiga ulanib bo'lmadi. Internet aloqasini tekshiring."
            if attempt == 0:
                await asyncio.sleep(1.5)
        raise AIError(last_error)

    async def one_shot(self, mode: str, user_text: str, **kwargs) -> str:
        return await self.chat(
            [{"role": "system", "content": SYSTEM_PROMPTS[mode]}, {"role": "user", "content": user_text}],
            **kwargs,
        )
