"""Barcha inline klaviaturalar."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton as B, InlineKeyboardMarkup

from services import content

LETTERS = ["A", "B", "C", "D", "E", "F"]


def _kb(rows: list[list[B]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back(cb: str = "menu:main") -> B:
    return B(text="⬅️ Orqaga", callback_data=cb)


HOME = B(text="🏠 Bosh menyu", callback_data="menu:main")


def nav(back_cb: str = "menu:main") -> list[B]:
    return [back(back_cb), HOME] if back_cb != "menu:main" else [HOME]


def main_menu(is_admin: bool = False) -> InlineKeyboardMarkup:
    rows = [
        [B(text="🤖 AI Yordamchi", callback_data="menu:ai"), B(text="🎓 Ta'lim Markazi", callback_data="menu:edu")],
        [B(text="🎨 Ijodiy Markaz", callback_data="menu:cr"), B(text="📅 Kundalik Yordamchi", callback_data="menu:day")],
        [B(text="🎮 Mini O'yinlar", callback_data="menu:game"), B(text="🏆 Reyting", callback_data="menu:top")],
        [B(text="👤 Profilim", callback_data="menu:prof"), B(text="ℹ️ Yordam", callback_data="menu:help")],
    ]
    if is_admin:
        rows.append([B(text="🛡 Admin Panel", callback_data="adm:home")])
    return _kb(rows)


def only_home() -> InlineKeyboardMarkup:
    return _kb([[HOME]])


# ------------------------------------------------------------------- AI
def ai_menu() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="💬 Suhbat", callback_data="ai:mode:chat"), B(text="🌐 Tarjima", callback_data="ai:mode:translate")],
        [B(text="💻 Kod yordami", callback_data="ai:mode:code"), B(text="✍️ Matn tahriri", callback_data="ai:mode:edit")],
        [B(text="🗑 Barcha tarixni tozalash", callback_data="ai:clear")],
        [HOME],
    ])


def ai_chat(mode: str, back_cb: str) -> InlineKeyboardMarkup:
    rows = []
    if mode != "translate":
        rows.append([B(text="🗑 Tarixni tozalash", callback_data="ai:clear")])
    rows.append([B(text="🔚 Suhbatni tugatish", callback_data=back_cb), HOME])
    return _kb(rows)


# ------------------------------------------------------------- Ta'lim / O'yin
def edu_menu() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="📖 Lug'at", callback_data="edu:vocab"), B(text="🧠 Lug'at testi", callback_data="qz:n:vocab")],
        [B(text="🧪 Ingliz tili testi", callback_data="qz:n:eng")],
        [B(text="❓ Savol-javob (AI)", callback_data="edu:tutor")],
        [B(text="📆 Kunlik bilim sinovi", callback_data="edu:daily")],
        [HOME],
    ])


def vocab_card() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="➡️ Keyingi so'z", callback_data="edu:vocab")],
        [B(text="🧠 Lug'at testi", callback_data="qz:n:vocab")],
        nav("menu:edu"),
    ])


def games_menu() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="🧩 Mantiqiy savol", callback_data="qz:n:logic"), B(text="🕵️ Topishmoq", callback_data="qz:n:riddle")],
        [B(text="🎯 Viktorina", callback_data="qz:n:quiz")],
        [B(text="🏆 Reyting jadvali", callback_data="menu:top")],
        [HOME],
    ])


def kind_back(kind: str) -> str:
    return "menu:edu" if kind in ("eng", "vocab") else "menu:game"


def question_kb(kind: str, qid: int, options: tuple[str, ...]) -> InlineKeyboardMarkup:
    rows = [[B(text=f"{LETTERS[i]}. {opt}"[:60], callback_data=f"qz:a:{kind}:{qid}:{i}")]
            for i, opt in enumerate(options)]
    rows.append(nav(kind_back(kind)))
    return _kb(rows)


def after_answer(kind: str) -> InlineKeyboardMarkup:
    return _kb([
        [B(text="➡️ Keyingi savol", callback_data=f"qz:n:{kind}")],
        nav(kind_back(kind)),
    ])


def daily_question_kb(step: int, options: tuple[str, ...]) -> InlineKeyboardMarkup:
    rows = [[B(text=f"{LETTERS[i]}. {opt}"[:60], callback_data=f"dq:a:{step}:{i}")]
            for i, opt in enumerate(options)]
    rows.append(nav("menu:edu"))
    return _kb(rows)


# --------------------------------------------------------------- Ijodiy
def creative_menu() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="🖼 Rasm yaratish", callback_data="cr:img"), B(text="🪄 Rasm prompti", callback_data="cr:imgprompt")],
        [B(text="📖 Hikoya", callback_data="cr:story"), B(text="🪶 She'r", callback_data="cr:poem")],
        [B(text="🎬 Video ssenariy", callback_data="cr:script"), B(text="🎞 Video prompt", callback_data="cr:vprompt")],
        [HOME],
    ])


def creative_input(kind: str, with_regen: bool = False) -> InlineKeyboardMarkup:
    rows = []
    if with_regen:
        rows.append([B(text="🔄 Boshqa variant", callback_data="cr:regen")])
    rows.append(nav("menu:cr"))
    return _kb(rows)


# -------------------------------------------------------------- Kundalik
def daily_menu() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="⏰ Eslatmalar", callback_data="day:rem"), B(text="✅ Vazifalar", callback_data="day:tasks:t")],
        [B(text="🗓 Kunlik reja", callback_data="day:tasks:p"), B(text="📊 Statistika", callback_data="day:stats")],
        [HOME],
    ])


def reminders_kb(items: list[dict]) -> InlineKeyboardMarkup:
    rows = [[B(text=f"🗑 {r['text'][:35]}", callback_data=f"day:rd:{r['id']}")] for r in items]
    rows.append([B(text="➕ Yangi eslatma", callback_data="day:ra")])
    rows.append(nav("menu:day"))
    return _kb(rows)


def tasks_kb(kind: str, items: list[dict]) -> InlineKeyboardMarkup:
    rows = []
    for t in items:
        mark = "✅" if t["done"] else "⬜"
        rows.append([
            B(text=f"{mark} {t['title'][:30]}", callback_data=f"day:tt:{kind}:{t['id']}"),
            B(text="🗑", callback_data=f"day:td:{kind}:{t['id']}"),
        ])
    rows.append([B(text="➕ Qo'shish", callback_data=f"day:ta:{kind}"),
                 B(text="🧹 Bajarilganlarni tozalash", callback_data=f"day:tc:{kind}")])
    rows.append(nav("menu:day"))
    return _kb(rows)


def to_daily() -> InlineKeyboardMarkup:
    return _kb([nav("menu:day")])


# -------------------------------------------------------------- Profil
def profile_kb() -> InlineKeyboardMarkup:
    return _kb([[B(text="🏆 Reyting", callback_data="menu:top")], [HOME]])


def top_kb() -> InlineKeyboardMarkup:
    return _kb([[B(text="🎮 O'ynash", callback_data="menu:game"), B(text="👤 Profilim", callback_data="menu:prof")], [HOME]])
