"""Admin panel klaviaturalari."""
from __future__ import annotations

from aiogram.types import InlineKeyboardButton as B, InlineKeyboardMarkup

from utils.texts import FEATURES


def _kb(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_home() -> InlineKeyboardMarkup:
    return _kb([
        [B(text="📊 Bot statistikasi", callback_data="adm:stats"), B(text="👥 Foydalanuvchilar", callback_data="adm:users")],
        [B(text="📢 E'lon tarqatish", callback_data="adm:bc"), B(text="✉️ Xabar yuborish", callback_data="adm:dm")],
        [B(text="🚫 Foydalanuvchini boshqarish", callback_data="adm:manage")],
        [B(text="⚙️ Funksiyalarni yoqish/o'chirish", callback_data="adm:feat")],
        [B(text="🏠 Bosh menyu", callback_data="menu:main")],
    ])


def back_admin() -> InlineKeyboardMarkup:
    return _kb([[B(text="⬅️ Admin panel", callback_data="adm:home")]])


def features_kb(states: dict[str, bool]) -> InlineKeyboardMarkup:
    rows = [[B(text=f"{'🟢' if states[k] else '🔴'} {name}", callback_data=f"adm:ft:{k}")]
            for k, name in FEATURES.items()]
    rows.append([B(text="⬅️ Admin panel", callback_data="adm:home")])
    return _kb(rows)


def confirm_broadcast(count: int) -> InlineKeyboardMarkup:
    return _kb([
        [B(text=f"✅ Yuborish ({count} kishi)", callback_data="adm:bc_go")],
        [B(text="❌ Bekor qilish", callback_data="adm:home")],
    ])


def user_manage(uid: int, banned: bool) -> InlineKeyboardMarkup:
    action = B(text="✅ Blokdan chiqarish", callback_data=f"adm:unban:{uid}") if banned \
        else B(text="🚫 Bloklash", callback_data=f"adm:ban:{uid}")
    return _kb([[action], [B(text="⬅️ Admin panel", callback_data="adm:home")]])
