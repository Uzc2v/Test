"""Admin panel — faqat .env dagi ADMIN_IDS ro'yxatidagi Telegram ID'lar uchun."""
import asyncio
import logging

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramAPIError, TelegramForbiddenError, TelegramRetryAfter
from aiogram.filters import BaseFilter, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message, TelegramObject

from config import Config
from database.db import Database
from keyboards import admin as akb
from utils import texts
from utils.helpers import show
from utils.texts import FEATURES, esc
from utils.timeutil import fmt_date, fmt_ts

log = logging.getLogger("nexora.admin")


class IsAdmin(BaseFilter):
    async def __call__(self, event: TelegramObject, config: Config) -> bool:
        user = getattr(event, "from_user", None)
        return bool(user and user.id in config.admin_ids)


_bg_tasks: set = set()  # fon vazifalariga havola (axlat yig'uvchi o'chirib yubormasligi uchun)

router = Router(name="admin")
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


class AdminStates(StatesGroup):
    broadcast = State()
    dm_id = State()
    dm_text = State()
    manage_id = State()


HOME_TEXT = f"{texts.BRAND}\n{texts.DIV}\n🛡 <b>Admin panel</b>\nBo'limni tanlang 👇"


@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(HOME_TEXT, reply_markup=akb.admin_home())


@router.callback_query(F.data == "adm:home")
async def adm_home(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, HOME_TEXT, akb.admin_home())


# ------------------------------------------------------------------ statistika
@router.callback_query(F.data == "adm:stats")
async def adm_stats(cb: CallbackQuery, db: Database, config: Config):
    s = await db.stats()
    top = await db.top_actions()
    actions = "\n".join(f"• {texts.ACTION_LABELS.get(a['action'], a['action'])}: {a['n']}" for a in top) or "—"
    states = await _feature_states(db)
    feats = "\n".join(f"{'🟢' if states[k] else '🔴'} {v}" for k, v in FEATURES.items())
    text = (
        f"{texts.BRAND}\n{texts.DIV}\n📊 <b>Bot statistikasi</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{s['total']}</b>\n"
        f"🟢 Faol (24 soat): <b>{s['active_24h']}</b>\n"
        f"🟢 Faol (7 kun): <b>{s['active_7d']}</b>\n"
        f"🆕 Bugun qo'shilgan: <b>{s['new_today']}</b>\n"
        f"🆕 7 kunda qo'shilgan: <b>{s['new_7d']}</b>\n"
        f"🚫 Bloklangan: <b>{s['banned']}</b>\n\n"
        f"⚡ Jami amallar: <b>{s['actions_total']}</b>\n"
        f"🤖 Tashqi API so'rovlari (24 soat): <b>{s['api_today']}</b>\n"
        f"⭐ Jami to'plangan ballar: <b>{s['points']}</b>\n"
        f"✅ Vazifalar: <b>{s['tasks']}</b> • ⏰ Faol eslatmalar: <b>{s['reminders']}</b>\n\n"
        f"🔥 <b>Eng ko'p ishlatiladigan amallar</b>\n{actions}\n\n"
        f"⚙️ <b>Funksiyalar</b>\n{feats}\n\n"
        f"🔌 AI: {'🟢 ulangan' if config.ai_enabled else '🔴 sozlanmagan'}"
    )
    await show(cb, text, akb.back_admin())


# ------------------------------------------------------------ foydalanuvchilar
@router.callback_query(F.data == "adm:users")
async def adm_users(cb: CallbackQuery, db: Database):
    users = await db.recent_users(15)
    lines = []
    for u in users:
        uname = f"@{esc(u['username'])}" if u["username"] else "—"
        flag = "🚫 " if u["is_banned"] else ""
        lines.append(f"{flag}<code>{u['id']}</code> {esc(u['full_name'][:20])} {uname} • {fmt_date(u['joined_at'])} • ⭐{u['points']}")
    body = "\n".join(lines) or "<i>Hali foydalanuvchi yo'q.</i>"
    await show(cb, f"{texts.BRAND}\n{texts.DIV}\n👥 <b>So'nggi 15 foydalanuvchi</b>\n\n{body}", akb.back_admin())


# ----------------------------------------------------------- boshqarish (ban)
@router.callback_query(F.data == "adm:manage")
async def adm_manage(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.manage_id)
    await show(cb, "🚫 <b>Foydalanuvchini boshqarish</b>\n\nFoydalanuvchining Telegram ID raqamini yuboring:",
               akb.back_admin())


async def _user_card(db: Database, uid: int) -> tuple[str, bool] | None:
    u = await db.get_user(uid)
    if not u:
        return None
    uname = f"@{esc(u['username'])}" if u["username"] else "—"
    text = (
        f"👤 <b>{esc(u['full_name'])}</b> {uname}\n🆔 <code>{u['id']}</code>\n"
        f"📅 Qo'shilgan: {fmt_date(u['joined_at'])}\n🕘 Oxirgi faollik: {fmt_ts(u['last_active'])}\n"
        f"⭐ Ballar: {u['points']}\nHolat: {'🚫 bloklangan' if u['is_banned'] else '🟢 faol'}"
    )
    return text, bool(u["is_banned"])


@router.message(AdminStates.manage_id, F.text, ~F.text.startswith("/"))
async def adm_manage_id(message: Message, state: FSMContext, db: Database):
    if not message.text.strip().isdigit():
        await message.answer("⚠️ ID faqat raqamlardan iborat bo'lishi kerak. Qaytadan yuboring.")
        return
    card = await _user_card(db, int(message.text.strip()))
    if not card:
        await message.answer("⚠️ Bunday foydalanuvchi bazada topilmadi.", reply_markup=akb.back_admin())
        return
    await state.clear()
    await message.answer(card[0], reply_markup=akb.user_manage(int(message.text.strip()), card[1]))


@router.callback_query(F.data.regexp(r"^adm:(ban|unban):\d+$"))
async def adm_ban(cb: CallbackQuery, db: Database, config: Config):
    _, action, uid_s = cb.data.split(":")
    uid = int(uid_s)
    if uid in config.admin_ids:
        await cb.answer("Adminni bloklab bo'lmaydi.", show_alert=True)
        return
    await db.set_banned(uid, action == "ban")
    log.info("Admin %s: %s foydalanuvchi %s", cb.from_user.id, action, uid)
    card = await _user_card(db, uid)
    if card:
        await show(cb, card[0], akb.user_manage(uid, card[1]))
    else:
        await cb.answer()


# ------------------------------------------------------------- funksiyalar
async def _feature_states(db: Database) -> dict[str, bool]:
    return {k: await db.feature_on(k) for k in FEATURES}


@router.callback_query(F.data == "adm:feat")
async def adm_features(cb: CallbackQuery, db: Database):
    await show(cb, f"{texts.BRAND}\n{texts.DIV}\n⚙️ <b>Funksiyalar</b>\n\nBo'limni yoqish/o'chirish uchun bosing.\n"
                   "🟢 yoqilgan • 🔴 o'chirilgan",
               akb.features_kb(await _feature_states(db)))


@router.callback_query(F.data.startswith("adm:ft:"))
async def adm_toggle(cb: CallbackQuery, db: Database):
    key = cb.data.split(":")[2]
    if key not in FEATURES:
        await cb.answer()
        return
    await db.set_feature(key, not await db.feature_on(key))
    await show(cb, f"{texts.BRAND}\n{texts.DIV}\n⚙️ <b>Funksiyalar</b>\n\n🟢 yoqilgan • 🔴 o'chirilgan",
               akb.features_kb(await _feature_states(db)))


# -------------------------------------------------------------- xabar (1 kishiga)
@router.callback_query(F.data == "adm:dm")
async def adm_dm(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.dm_id)
    await show(cb, "✉️ <b>Xabar yuborish</b>\n\nXabar oluvchining Telegram ID raqamini yuboring:", akb.back_admin())


@router.message(AdminStates.dm_id, F.text, ~F.text.startswith("/"))
async def adm_dm_id(message: Message, state: FSMContext, db: Database):
    if not message.text.strip().isdigit() or not await db.get_user(int(message.text.strip())):
        await message.answer("⚠️ Bunday ID bazada topilmadi. Qaytadan yuboring.")
        return
    await state.update_data(target=int(message.text.strip()))
    await state.set_state(AdminStates.dm_text)
    await message.answer("✍️ Endi yuboriladigan xabar matnini yozing:")


@router.message(AdminStates.dm_text, F.text, ~F.text.startswith("/"))
async def adm_dm_send(message: Message, state: FSMContext):
    target = (await state.get_data())["target"]
    await state.clear()
    try:
        await message.bot.send_message(target, f"📩 <b>NEXORA xabari</b>\n{texts.DIV}\n{esc(message.text)}")
        await message.answer("✅ Xabar yuborildi.", reply_markup=akb.back_admin())
    except TelegramForbiddenError:
        await message.answer("⚠️ Foydalanuvchi botni bloklagan, xabar yetmadi.", reply_markup=akb.back_admin())
    except TelegramAPIError as e:
        await message.answer(f"⚠️ Yuborib bo'lmadi: {esc(str(e))}", reply_markup=akb.back_admin())


# ------------------------------------------------------------ e'lon (hammaga)
@router.callback_query(F.data == "adm:bc")
async def adm_bc(cb: CallbackQuery, state: FSMContext):
    await state.set_state(AdminStates.broadcast)
    await show(cb, "📢 <b>E'lon tarqatish</b>\n\nBarcha foydalanuvchilarga yuboriladigan e'lonni yuboring "
                   "(matn, rasm, video yoki fayl bo'lishi mumkin).\n<i>Yuborishdan oldin tasdiq so'raladi.</i>",
               akb.back_admin())


@router.message(AdminStates.broadcast)
async def adm_bc_preview(message: Message, state: FSMContext, db: Database):
    await state.update_data(src_chat=message.chat.id, src_msg=message.message_id,
                            is_text=bool(message.text), text=message.text or "")
    count = len(await db.all_user_ids())
    await message.answer("👆 E'lon ko'rinishi shunday bo'ladi. Tasdiqlaysizmi?",
                         reply_markup=akb.confirm_broadcast(count))


async def _send_one(bot: Bot, uid: int, data: dict) -> str:
    for _ in range(2):
        try:
            if data["is_text"]:
                await bot.send_message(uid, f"📢 <b>E'LON</b>\n{texts.DIV}\n{esc(data['text'])}")
            else:
                await bot.copy_message(uid, data["src_chat"], data["src_msg"])
            return "ok"
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
        except TelegramForbiddenError:
            return "blocked"
        except TelegramAPIError:
            return "failed"
    return "failed"


async def _broadcast(bot: Bot, db: Database, admin_id: int, data: dict) -> None:
    ids = await db.all_user_ids()
    stat = {"ok": 0, "blocked": 0, "failed": 0}
    for uid in ids:
        stat[await _send_one(bot, uid, data)] += 1
        await asyncio.sleep(0.05)  # Telegram limiti: ~30 xabar/soniya
    log.info("E'lon yakunlandi: %s", stat)
    await bot.send_message(
        admin_id,
        f"📢 <b>E'lon yakunlandi</b>\n\n✅ Yetkazildi: <b>{stat['ok']}</b>\n"
        f"🚫 Botni bloklaganlar: <b>{stat['blocked']}</b>\n⚠️ Xato: <b>{stat['failed']}</b>",
        reply_markup=akb.back_admin(),
    )


@router.callback_query(F.data == "adm:bc_go")
async def adm_bc_go(cb: CallbackQuery, state: FSMContext, db: Database):
    data = await state.get_data()
    await state.clear()
    if "src_msg" not in data:
        await cb.answer("E'lon topilmadi. Qaytadan boshlang.", show_alert=True)
        return
    await cb.answer("Yuborish boshlandi")
    await cb.message.edit_text("⏳ E'lon yuborilmoqda... Tugagach, hisobot keladi.")
    task = asyncio.create_task(_broadcast(cb.bot, db, cb.from_user.id, data))
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)
