"""Umumiy yordamchi funksiyalar."""
from __future__ import annotations

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message


async def show(target: CallbackQuery | Message, text: str, kb: InlineKeyboardMarkup | None = None,
               ack: bool = True) -> None:
    """Callback bo'lsa xabarni tahrirlaydi (toza navigatsiya), bo'lmasa yangi xabar yuboradi.

    ack=False — callback'ga chaqiruvchi o'zi javob bergan bo'lsa (ikki marta javob berilmasligi uchun).
    """
    if isinstance(target, CallbackQuery):
        try:
            await target.message.edit_text(text, reply_markup=kb)
        except TelegramBadRequest as e:
            if "message is not modified" in str(e):
                pass
            else:  # masalan, xabar rasm edi yoki juda eski
                await target.message.answer(text, reply_markup=kb)
        if ack:
            try:
                await target.answer()
            except TelegramBadRequest:
                pass  # eskirgan callback — e'tibor bermaymiz
    else:
        await target.answer(text, reply_markup=kb)


def split_text(text: str, limit: int = 4000) -> list[str]:
    """Uzun matnni Telegram limitiga (4096) mos bo'laklarga ajratadi."""
    chunks: list[str] = []
    while len(text) > limit:
        cut = text.rfind("\n", 0, limit)
        if cut < limit // 2:
            cut = text.rfind(" ", 0, limit)
        if cut < limit // 2:
            cut = limit
        chunks.append(text[:cut].rstrip())
        text = text[cut:].lstrip()
    if text:
        chunks.append(text)
    return chunks


def feature_for_callback(data: str) -> str | None:
    """Callback ma'lumotidan qaysi funksiya (bo'lim) ga tegishli ekanini aniqlaydi."""
    p = data.split(":")
    s = p[0]
    if s == "menu" and len(p) > 1:
        return {"ai": "ai", "edu": "education", "cr": "creative", "day": "daily", "game": "games"}.get(p[1])
    if s == "ai":
        return "ai"
    if s in ("edu", "dq"):
        return "education"
    if s == "cr":
        return "creative"
    if s == "day":
        return "daily"
    if s == "game":
        return "games"
    if s == "qz" and len(p) > 2:
        return "education" if p[2] in ("eng", "vocab") else "games"
    return None
