"""AI Yordamchi: suhbat, tarjima, kod, matn tahriri va ingliz tili o'qituvchisi."""
import logging

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from aiogram.utils.chat_action import ChatActionSender

from config import Config
from database.db import Database
from keyboards import menus as kb
from services.ai import AIError, AIService, SYSTEM_PROMPTS
from utils import texts
from utils.helpers import show, split_text
from utils.timeutil import day_start_ts

log = logging.getLogger("nexora.ai_chat")
router = Router(name="ai_chat")

_busy: set[int] = set()


class AIStates(StatesGroup):
    chatting = State()


@router.callback_query(F.data == "menu:ai")
async def ai_menu(cb: CallbackQuery, state: FSMContext, ai: AIService):
    await state.clear()
    text = texts.AI_MENU + ("" if ai.enabled else "\n\n" + texts.AI_NOT_CONFIGURED)
    await show(cb, text, kb.ai_menu())


async def _enter_mode(cb: CallbackQuery, state: FSMContext, mode: str, back_cb: str, ai: AIService):
    if not ai.enabled:
        await cb.answer("AI xizmati sozlanmagan", show_alert=True)
        await show(cb, texts.AI_NOT_CONFIGURED, kb.only_home())
        return
    await state.set_state(AIStates.chatting)
    await state.update_data(mode=mode, back=back_cb)
    await show(cb, texts.AI_MODE_INTRO[mode] + "\n\n<i>✍️ Xabaringizni yozing...</i>", kb.ai_chat(mode, back_cb))


@router.callback_query(F.data.startswith("ai:mode:"))
async def ai_mode(cb: CallbackQuery, state: FSMContext, ai: AIService):
    mode = cb.data.split(":")[2]
    if mode not in ("chat", "translate", "code", "edit"):
        await cb.answer()
        return
    await _enter_mode(cb, state, mode, "menu:ai", ai)


@router.callback_query(F.data == "edu:tutor")
async def edu_tutor(cb: CallbackQuery, state: FSMContext, ai: AIService):
    await _enter_mode(cb, state, "tutor", "menu:edu", ai)


@router.callback_query(F.data == "ai:clear")
async def ai_clear(cb: CallbackQuery, state: FSMContext, db: Database):
    mode = (await state.get_data()).get("mode")
    await db.clear_history(cb.from_user.id, mode)
    await cb.answer("🗑 Suhbat tarixi tozalandi", show_alert=True)


@router.message(AIStates.chatting, F.text, ~F.text.startswith("/"))
async def ai_message(message: Message, state: FSMContext, db: Database, ai: AIService,
                     config: Config, is_admin: bool):
    uid = message.from_user.id
    if not await db.feature_on("ai") and not is_admin:
        await state.clear()
        await message.answer("🔒 Bu bo'lim vaqtincha o'chirilgan.", reply_markup=kb.only_home())
        return
    if not ai.enabled:
        await message.answer(texts.AI_NOT_CONFIGURED, reply_markup=kb.only_home())
        return
    if uid in _busy:
        await message.answer(texts.AI_BUSY)
        return
    text = message.text.strip()
    if len(text) > 4000:
        await message.answer("⚠️ Xabar juda uzun (4000 belgidan oshmasin). Iltimos, qisqartiring.")
        return

    data = await state.get_data()
    mode = data.get("mode", "chat")
    back_cb = data.get("back", "menu:ai")

    if not is_admin:
        used = await db.count_activity(uid, "api", day_start_ts())
        if used >= config.ai_daily_limit:
            await message.answer(texts.AI_LIMIT.format(n=config.ai_daily_limit), reply_markup=kb.only_home())
            return

    _busy.add(uid)
    try:
        history = [] if mode == "translate" else await db.get_history(uid, mode, 10)
        messages = [{"role": "system", "content": SYSTEM_PROMPTS[mode]}, *history,
                    {"role": "user", "content": text}]
        async with ChatActionSender.typing(bot=message.bot, chat_id=message.chat.id):
            reply = await ai.chat(messages)
    except AIError as e:
        await message.answer(f"⚠️ {e.user_message}")
        return
    except Exception:
        log.exception("AI handlerida kutilmagan xato")
        await message.answer("⚠️ Kutilmagan xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.")
        return
    finally:
        _busy.discard(uid)

    if mode != "translate":
        await db.save_message(uid, mode, "user", text)
        await db.save_message(uid, mode, "assistant", reply)
    await db.log(uid, f"ai_{mode}")
    await db.log(uid, "api")

    chunks = split_text(reply)
    for i, chunk in enumerate(chunks):
        last = i == len(chunks) - 1
        # AI javobi oddiy matn sifatida yuboriladi (Markdown/HTML buzilmasligi uchun)
        await message.answer(chunk, parse_mode=None,
                             reply_markup=kb.ai_chat(mode, back_cb) if last else None)


@router.message(AIStates.chatting, ~F.text)
async def ai_non_text(message: Message):
    await message.answer("📝 Hozircha faqat matnli xabarlar qabul qilinadi. Iltimos, matn yozing.")
