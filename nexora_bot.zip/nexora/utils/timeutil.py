"""Vaqt bilan ishlash yordamchilari (UTC+N zona, .env dagi TZ_OFFSET_HOURS)."""
from __future__ import annotations

import re
import time
from datetime import datetime, timedelta, timezone

_tz = timezone(timedelta(hours=5))

WEEKDAYS_UZ = ["Du", "Se", "Chor", "Pay", "Ju", "Sha", "Yak"]


def set_offset(hours: int) -> None:
    global _tz
    _tz = timezone(timedelta(hours=hours))


def now_local() -> datetime:
    return datetime.now(_tz)


def today_str() -> str:
    return now_local().strftime("%Y-%m-%d")


def day_start_ts() -> int:
    n = now_local().replace(hour=0, minute=0, second=0, microsecond=0)
    return int(n.timestamp())


def fmt_ts(ts: int) -> str:
    return datetime.fromtimestamp(ts, _tz).strftime("%d.%m.%Y %H:%M")


def fmt_date(ts: int) -> str:
    return datetime.fromtimestamp(ts, _tz).strftime("%d.%m.%Y")


def local_date(ts: int):
    return datetime.fromtimestamp(ts, _tz).date()


def last_days(n: int):
    today = now_local().date()
    return [today - timedelta(days=i) for i in range(n - 1, -1, -1)]


def now_ts() -> int:
    return int(time.time())


_TIME = re.compile(r"^(\d{1,2}):(\d{2})$")
_DATE = re.compile(r"^(\d{1,2})\.(\d{1,2})(?:\.(\d{4}))?$")
_REL = re.compile(r"^\+(\d{1,4})$")


def parse_reminder(text: str):
    """Eslatma matnini (vaqt + matn) tahlil qiladi.

    Formatlar:
      18:30 Dori ichish
      25.12 09:00 Tug'ilgan kun
      25.12.2026 09:00 Imtihon
      +30 Choyni o'chirish      (30 daqiqadan keyin)

    Natija: (UTC timestamp, matn) yoki None.
    """
    parts = text.strip().split()
    if not parts:
        return None
    now = now_local()

    rel = _REL.match(parts[0])
    if rel:
        minutes = int(rel.group(1))
        if minutes < 1:
            return None
        due = now + timedelta(minutes=minutes)
        body = " ".join(parts[1:])
    else:
        date_m = _DATE.match(parts[0]) if len(parts) >= 2 else None
        time_m = _TIME.match(parts[1]) if date_m else None
        if date_m and time_m:
            day, month = int(date_m.group(1)), int(date_m.group(2))
            year = int(date_m.group(3)) if date_m.group(3) else now.year
            hour, minute = int(time_m.group(1)), int(time_m.group(2))
            try:
                due = datetime(year, month, day, hour, minute, tzinfo=_tz)
                if not date_m.group(3) and due <= now:
                    due = datetime(year + 1, month, day, hour, minute, tzinfo=_tz)
            except ValueError:
                return None
            body = " ".join(parts[2:])
        else:
            t = _TIME.match(parts[0])
            if not t:
                return None
            hour, minute = int(t.group(1)), int(t.group(2))
            if hour > 23 or minute > 59:
                return None
            due = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if due <= now:
                due += timedelta(days=1)
            body = " ".join(parts[1:])

    body = body.strip()
    if not body or due <= now:
        return None
    return int(due.timestamp()), body[:300]
