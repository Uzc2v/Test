"""Ta'lim va o'yin kontenti: lug'at, testlar, viktorina, topishmoq, mantiqiy savollar.

Variantlar tartibi savol matnidan olingan barqaror (deterministik) urug' bilan
aralashtiriladi, shuning uchun bot qayta ishga tushganda ham javoblar to'g'ri tekshiriladi.
"""
from __future__ import annotations

import random
import zlib
from dataclasses import dataclass


@dataclass(frozen=True)
class Question:
    text: str
    options: tuple[str, ...]
    answer: int


def _build(text: str, correct: str, wrong: list[str]) -> Question:
    options = [correct] + list(wrong)
    random.Random(zlib.crc32(text.encode("utf-8"))).shuffle(options)
    return Question(text, tuple(options), options.index(correct))


# ----------------------------------------------------------------- LUG'AT
# (inglizcha, o'zbekcha, inglizcha misol, o'zbekcha misol)
VOCAB: list[tuple[str, str, str, str]] = [
    ("apple", "olma", "I eat an apple every day.", "Men har kuni olma yeyman."),
    ("book", "kitob", "This book is very interesting.", "Bu kitob juda qiziqarli."),
    ("water", "suv", "Please give me some water.", "Iltimos, menga suv bering."),
    ("house", "uy", "Our house is near the park.", "Bizning uyimiz bog' yonida."),
    ("friend", "do'st", "She is my best friend.", "U mening eng yaqin do'stim."),
    ("school", "maktab", "I go to school by bus.", "Men maktabga avtobusda boraman."),
    ("teacher", "o'qituvchi", "The teacher is very kind.", "O'qituvchi juda mehribon."),
    ("family", "oila", "I love my family.", "Men oilamni yaxshi ko'raman."),
    ("city", "shahar", "Tashkent is a big city.", "Toshkent katta shahar."),
    ("street", "ko'cha", "The street is quiet at night.", "Ko'cha kechasi tinch bo'ladi."),
    ("morning", "ertalab", "I wake up early in the morning.", "Men ertalab erta uyg'onaman."),
    ("night", "tun", "The night is dark and cold.", "Tun qorong'i va sovuq."),
    ("time", "vaqt", "I don't have much time.", "Menda vaqt ko'p emas."),
    ("work", "ish", "He goes to work at eight.", "U soat sakkizda ishga boradi."),
    ("money", "pul", "I need some money.", "Menga biroz pul kerak."),
    ("food", "ovqat", "The food is delicious.", "Ovqat juda mazali."),
    ("bread", "non", "We buy fresh bread every morning.", "Biz har ertalab yangi non olamiz."),
    ("tea", "choy", "Would you like some tea?", "Choy ichasizmi?"),
    ("sun", "quyosh", "The sun is bright today.", "Bugun quyosh yorqin."),
    ("moon", "oy", "The moon is full tonight.", "Bu kecha oy to'lin."),
    ("river", "daryo", "The river is very long.", "Daryo juda uzun."),
    ("mountain", "tog'", "We climbed a high mountain.", "Biz baland tog'ga chiqdik."),
    ("tree", "daraxt", "There is a big tree in the yard.", "Hovlida katta daraxt bor."),
    ("flower", "gul", "She gave me a red flower.", "U menga qizil gul berdi."),
    ("car", "mashina", "My father has a new car.", "Dadamning yangi mashinasi bor."),
    ("road", "yo'l", "The road is long.", "Yo'l uzoq."),
    ("window", "deraza", "Please open the window.", "Iltimos, derazani oching."),
    ("door", "eshik", "Close the door, please.", "Iltimos, eshikni yoping."),
    ("happy", "xursand", "I am happy today.", "Bugun men xursandman."),
    ("big", "katta", "This is a big room.", "Bu katta xona."),
    ("small", "kichik", "She has a small bag.", "Uning kichik sumkasi bor."),
    ("fast", "tez", "He runs very fast.", "U juda tez yuguradi."),
    ("beautiful", "go'zal", "What a beautiful garden!", "Qanday go'zal bog'!"),
    ("difficult", "qiyin", "This exam was difficult.", "Bu imtihon qiyin edi."),
    ("easy", "oson", "The task is easy.", "Vazifa oson."),
    ("to learn", "o'rganmoq", "I want to learn English.", "Men ingliz tilini o'rganmoqchiman."),
    ("to read", "o'qimoq", "I like to read books.", "Men kitob o'qishni yaxshi ko'raman."),
    ("to write", "yozmoq", "Please write your name.", "Iltimos, ismingizni yozing."),
    ("to speak", "gapirmoq", "Can you speak English?", "Ingliz tilida gapira olasizmi?"),
    ("to help", "yordam bermoq", "Can you help me?", "Menga yordam bera olasizmi?"),
]


def vocab_question(qid: int) -> Question:
    en, uz, _, _ = VOCAB[qid]
    rng = random.Random(qid * 7919 + 13)
    others = [w[1] for i, w in enumerate(VOCAB) if i != qid and w[1] != uz]
    wrong = rng.sample(others, 3)
    options = [uz] + wrong
    rng.shuffle(options)
    return Question(f"«{en}» so'zining o'zbekcha tarjimasi qaysi?", tuple(options), options.index(uz))


# ----------------------------------------------------------- INGLIZ TILI TESTI
_ENG_RAW = [
    ("She ___ to school every day.", "goes", ["go", "going", "gone"]),
    ("I ___ a book right now.", "am reading", ["read", "reads", "was read"]),
    ("They ___ football yesterday.", "played", ["play", "plays", "playing"]),
    ("My brother is ___ than me.", "taller", ["tall", "tallest", "more tall"]),
    ("There ___ three cats in the garden.", "are", ["is", "am", "be"]),
    ("I have ___ orange.", "an", ["a", "the", "some"]),
    ("___ you speak English?", "Do", ["Does", "Is", "Are"]),
    ("My parents ___ in Samarkand.", "live", ["lives", "living", "is live"]),
    ("She has ___ finished her homework.", "already", ["yesterday", "tomorrow", "ago"]),
    ("If it rains, I ___ stay at home.", "will", ["would", "did", "am"]),
    ("This is ___ best film I have ever seen.", "the", ["a", "an", "some"]),
    ("I ___ him at the market yesterday.", "saw", ["see", "have seen", "seeing"]),
    ("He ___ like tea.", "doesn't", ["don't", "isn't", "not"]),
    ("The opposite of 'big' is ...", "small", ["high", "wide", "old"]),
    ("The plural of 'child' is ...", "children", ["childs", "childrens", "childes"]),
    ("I'm interested ___ music.", "in", ["on", "at", "for"]),
    ("She is good ___ math.", "at", ["in", "on", "with"]),
    ("How ___ apples do you want?", "many", ["much", "long", "more"]),
]
ENG: list[Question] = [_build(*q) for q in _ENG_RAW]

# --------------------------------------------------------------- VIKTORINA
_QUIZ_RAW = [
    ("O'zbekiston poytaxti qaysi shahar?", "Toshkent", ["Samarqand", "Buxoro", "Xiva"]),
    ("Registon maydoni qaysi shaharda joylashgan?", "Samarqand", ["Buxoro", "Xiva", "Toshkent"]),
    ("Amir Temur qaysi shaharda tug'ilgan?", "Shahrisabz", ["Samarqand", "Toshkent", "Buxoro"]),
    ("O'zbekiston Mustaqillik kuni qachon nishonlanadi?", "1-sentabr", ["9-may", "21-mart", "8-dekabr"]),
    ("Quyosh tizimidagi eng katta sayyora qaysi?", "Yupiter", ["Saturn", "Yer", "Mars"]),
    ("Suvning kimyoviy formulasi qanday?", "H2O", ["CO2", "O2", "NaCl"]),
    ("Dunyodagi eng katta okean qaysi?", "Tinch okeani", ["Atlantika okeani", "Hind okeani", "Shimoliy Muz okeani"]),
    ("«Xamsa» asarining muallifi kim?", "Alisher Navoiy", ["Zahiriddin Bobur", "Abdulla Qodiriy", "Cho'lpon"]),
    ("Algebra fanining asoschisi hisoblangan buyuk bobokalonimiz kim?", "Al-Xorazmiy", ["Ibn Sino", "Beruniy", "Ulug'bek"]),
    ("Katta yoshdagi odam skeletida nechta suyak bor?", "206", ["106", "306", "256"]),
    ("Dunyodagi eng baland cho'qqi qaysi?", "Everest (Jomolungma)", ["K2", "Elbrus", "Kilimanjaro"]),
    ("Mirzo Ulug'bek qaysi fan sohasida mashhur?", "Astronomiya", ["Tibbiyot", "Adabiyot", "Me'morchilik"]),
    ("O'zbekiston milliy valyutasi nima?", "So'm", ["Tenge", "Rubl", "Dinor"]),
    ("Qaysi qit'a eng katta?", "Osiyo", ["Afrika", "Yevropa", "Shimoliy Amerika"]),
    ("Yorug'likning vakuumdagi tezligi taxminan qancha?", "300 000 km/s", ["30 000 km/s", "3 000 km/s", "3 000 000 km/s"]),
    ("Python kompyuter sohasida nima?", "Dasturlash tili", ["Brauzer", "Operatsion tizim", "Antivirus"]),
    ("Eng kichik tub son qaysi?", "2", ["1", "0", "3"]),
    ("«Boburnoma» muallifi kim?", "Zahiriddin Muhammad Bobur", ["Alisher Navoiy", "Amir Temur", "Mirzo Ulug'bek"]),
    ("O'simliklar fotosintez jarayonida qaysi gazni ajratib chiqaradi?", "Kislorod", ["Azot", "Vodorod", "Geliy"]),
    ("Ibn Sinoning mashhur tibbiyot asari qanday nomlanadi?", "«Tib qonunlari»", ["«Xamsa»", "«Boburnoma»", "«Al-jabr»"]),
]
QUIZ: list[Question] = [_build(*q) for q in _QUIZ_RAW]

# -------------------------------------------------------------- TOPISHMOQLAR
_RIDDLE_RAW = [
    ("Hech kim uni ko'rmaydi, lekin hamma eshitadi. Sen gapirsang, u so'zingni takrorlaydi. U nima?",
     "Aks-sado", ["Shamol", "Soya", "Tush"]),
    ("Sen qancha ko'p yursang, ortingda shuncha ko'p qoladi. U nima?",
     "Izlar", ["Shamol", "Suv", "Quyosh"]),
    ("Shaharlari bor, lekin uylari yo'q. Daryolari bor, lekin suvi yo'q. U nima?",
     "Xarita", ["Kitob", "Daftar", "Eshik"]),
    ("Doim keladi, lekin hech qachon kelmaydi. U nima?",
     "Ertaga", ["Kecha", "Bugun", "Yoz"]),
    ("Qo'llari bor, lekin chapak chalolmaydi. Yuzi bor, lekin kulmaydi. U nima?",
     "Soat", ["Daraxt", "Kitob", "Chiroq"]),
    ("Tishlari bor, lekin hech narsani tishlamaydi. U nima?",
     "Taroq", ["Qalam", "Stakan", "Kitob"]),
    ("Qancha ko'p olib tashlasang, shuncha kattalashadi. U nima?",
     "Chuqur o'ra", ["Tog'", "Daraxt", "Bola"]),
    ("Sharqdan chiqadi, g'arbda botadi, hammaga nur va issiqlik beradi. U nima?",
     "Quyosh", ["Oy", "Chiroq", "Bulut"]),
    ("Ikki ota va ikki o'g'il uchta olma yedi, har biri bittadan. Bu qanday bo'lishi mumkin?",
     "Ular 3 kishi: bobo, ota va nevara", ["Bitta olma ikkiga bo'lingan", "Bittasi ikkita yegan", "Bu mumkin emas"]),
    ("Suvga tushsa ham ho'l bo'lmaydi. U nima?",
     "Soya", ["Tosh", "Qum", "Sovun"]),
]
RIDDLE: list[Question] = [_build(*q) for q in _RIDDLE_RAW]

# ------------------------------------------------------------ MANTIQIY SAVOLLAR
_LOGIC_RAW = [
    ("2, 4, 8, 16, ... qatorning keyingi soni qaysi?", "32", ["24", "30", "18"]),
    ("5 ta mushuk 5 ta sichqonni 5 daqiqada tutsa, 100 ta mushuk 100 ta sichqonni necha daqiqada tutadi?",
     "5 daqiqa", ["100 daqiqa", "20 daqiqa", "1 daqiqa"]),
    ("1, 1, 2, 3, 5, 8, ... keyingi son qaysi?", "13", ["11", "12", "15"]),
    ("Xonada 3 ta katta mushuk bor, har birining 3 tadan mushukchasi bor. Xonada jami nechta mushuk?",
     "12", ["9", "6", "15"]),
    ("Bugun chorshanba bo'lsa, 10 kundan keyin qaysi kun bo'ladi?", "Shanba", ["Juma", "Yakshanba", "Payshanba"]),
    ("3 ga ham, 4 ga ham, 5 ga ham qoldiqsiz bo'linadigan eng kichik natural son qaysi?", "60", ["12", "30", "120"]),
    ("1 dan 10 gacha bo'lgan sonlar yig'indisi nechaga teng?", "55", ["50", "45", "60"]),
    ("3 soat 20 daqiqa necha daqiqa bo'ladi?", "200", ["320", "180", "260"]),
    ("7, 14, 21, 28, ... keyingi son qaysi?", "35", ["32", "42", "36"]),
    ("100 dan 7 ni ketma-ket 5 marta ayirsak, nechta qoladi?", "65", ["63", "70", "35"]),
    ("Ota va o'g'lining yoshlari yig'indisi 50, ota o'g'ildan 30 yosh katta. O'g'il necha yoshda?",
     "10", ["20", "15", "5"]),
    ("Ali Validan 2 baravar ko'p olma oldi, ikkalasida jami 12 ta olma bor. Alida nechta olma bor?",
     "8", ["6", "4", "10"]),
]
LOGIC: list[Question] = [_build(*q) for q in _LOGIC_RAW]

# ------------------------------------------------------------------ umumiy API
POOLS = {"eng": ENG, "quiz": QUIZ, "riddle": RIDDLE, "logic": LOGIC}
KINDS = ("eng", "vocab", "quiz", "riddle", "logic")

KIND_TITLES = {
    "eng": "🧪 Ingliz tili testi",
    "vocab": "🧠 Lug'at testi",
    "quiz": "🎯 Viktorina",
    "riddle": "🕵️ Topishmoq",
    "logic": "🧩 Mantiqiy savol",
}
KIND_POINTS = {"eng": 5, "vocab": 3, "quiz": 5, "riddle": 7, "logic": 10}


def pool_size(kind: str) -> int:
    return len(VOCAB) if kind == "vocab" else len(POOLS[kind])


def random_qid(kind: str) -> int:
    return random.randrange(pool_size(kind))


def get_question(kind: str, qid: int) -> Question | None:
    if kind not in KINDS or not (0 <= qid < pool_size(kind)):
        return None
    return vocab_question(qid) if kind == "vocab" else POOLS[kind][qid]


# ---------------------------------------------------------------- kunlik sinov
DAILY_COUNT = 5


def daily_questions(day: str) -> list[tuple[str, int]]:
    """Berilgan kun uchun hamma foydalanuvchiga bir xil 5 ta savol."""
    pool = [("eng", i) for i in range(len(ENG))] + [("quiz", i) for i in range(len(QUIZ))]
    seed = int(day.replace("-", ""))
    return random.Random(seed).sample(pool, DAILY_COUNT)
