"""Umumiy savol-javob mexanizmi: ingliz testi, lug'at testi, viktorina, topishmoq, mantiq."""
from aiogram import F, Router
from aiogram.types import CallbackQuery

from database.db import Database
from keyboards import menus as kb
from services import content
from utils import texts
from utils.helpers import show
from utils.timeutil import today_str

router = Router(name="quiz")


@router.callback_query(F.data.startswith("qz:n:"))
async def new_question(cb: CallbackQuery):
    kind = cb.data.split(":")[2]
    if kind not in content.KINDS:
        await cb.answer()
        return
    qid = content.random_qid(kind)
    q = content.get_question(kind, qid)
    text = (
        f"{texts.BRAND}\n{texts.DIV}\n{content.KIND_TITLES[kind]} "
        f"(+{content.KIND_POINTS[kind]} ball)\n\n❓ <b>{texts.esc(q.text)}</b>"
    )
    await show(cb, text, kb.question_kb(kind, qid, q.options))


@router.callback_query(F.data.startswith("qz:a:"))
async def answer_question(cb: CallbackQuery, db: Database):
    try:
        _, _, kind, qid_s, choice_s = cb.data.split(":")
        qid, choice = int(qid_s), int(choice_s)
    except ValueError:
        await cb.answer()
        return
    q = content.get_question(kind, qid)
    if q is None or not (0 <= choice < len(q.options)):
        await cb.answer()
        return

    uid = cb.from_user.id
    correct = choice == q.answer
    points = 0
    if correct and await db.mark_answered(uid, f"{kind}:{qid}", today_str()):
        points = content.KIND_POINTS[kind]
        await db.add_points(uid, points)
    await db.log(uid, "quiz_ok" if correct else "quiz_bad")

    if correct:
        verdict = "✅ <b>To'g'ri!</b>" + (f" +{points} ball ⭐" if points else
                                         "\n<i>Bu savol uchun bugun ball olgansiz.</i>")
    else:
        verdict = f"❌ <b>Noto'g'ri.</b>\nTo'g'ri javob: <b>{texts.esc(q.options[q.answer])}</b>"
    text = (
        f"{texts.BRAND}\n{texts.DIV}\n{content.KIND_TITLES[kind]}\n\n"
        f"❓ {texts.esc(q.text)}\n\n"
        f"Sizning javobingiz: <b>{texts.esc(q.options[choice])}</b>\n\n{verdict}"
    )
    await show(cb, text, kb.after_answer(kind))
