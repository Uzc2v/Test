"""NEXORA — Telegram bot. Ishga tushirish:  python bot.py"""
import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramNetworkError, TelegramUnauthorizedError
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import BotCommand, ErrorEvent

from admin.panel import router as admin_router
from config import load_config
from database.db import Database
from handlers import ai_chat, creative, daily, education, games, profile, quiz, start
from services.ai import AIService
from services.images import ImageService
from services.scheduler import reminder_loop
from utils.logger import setup_logging
from utils.middlewares import AccessMiddleware
from utils.timeutil import set_offset

log = logging.getLogger("nexora")

COMMANDS = [
    BotCommand(command="start", description="🚀 Botni ishga tushirish"),
    BotCommand(command="menu", description="🏠 Bosh menyu"),
    BotCommand(command="profile", description="👤 Profilim"),
    BotCommand(command="top", description="🏆 Reyting"),
    BotCommand(command="help", description="ℹ️ Yordam"),
    BotCommand(command="cancel", description="❌ Amalni bekor qilish"),
]


async def on_error(event: ErrorEvent) -> bool:
    log.error("Handlerda xato: %s", event.exception, exc_info=event.exception)
    update = event.update
    try:
        if update.callback_query:
            await update.callback_query.answer(
                "⚠️ Xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring.", show_alert=True)
        elif update.message:
            await update.message.answer("⚠️ Xatolik yuz berdi. Birozdan so'ng qayta urinib ko'ring yoki /start yuboring.")
    except Exception:
        pass
    return True


async def main() -> None:
    config = load_config()
    setup_logging(config)
    set_offset(config.tz_offset_hours)

    db = Database(config.db_path)
    await db.connect()
    ai = AIService(config)
    images = ImageService(config)

    bot = Bot(token=config.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage(), db=db, config=config, ai=ai, images=images)

    access = AccessMiddleware()
    dp.message.outer_middleware(access)
    dp.callback_query.outer_middleware(access)
    dp.errors.register(on_error)

    # Tartib muhim: buyruqlar (start) holatga bog'liq handlerlardan oldin ishlashi kerak
    dp.include_routers(
        start.router, admin_router, profile.router, ai_chat.router, education.router,
        quiz.router, creative.router, daily.router, games.router,
    )

    reminder_task = None
    try:
        me = await bot.get_me()
        log.info("NEXORA ishga tushdi: @%s | AI: %s | Adminlar: %d ta",
                 me.username, "yoqilgan" if config.ai_enabled else "SOZLANMAGAN", len(config.admin_ids))
        if not config.admin_ids:
            log.warning("ADMIN_IDS bo'sh — admin panel hech kimga ochilmaydi!")
        await bot.delete_webhook(drop_pending_updates=True)
        await bot.set_my_commands(COMMANDS)
        reminder_task = asyncio.create_task(reminder_loop(bot, db))
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    except TelegramUnauthorizedError:
        log.error("❌ BOT_TOKEN noto'g'ri! @BotFather'dan olingan tokenni .env ga to'g'ri yozing.")
    except TelegramNetworkError as e:
        log.error("❌ Telegram'ga ulanib bo'lmadi: %s. Internetni tekshiring.", e)
    finally:
        if reminder_task:
            reminder_task.cancel()
        await ai.close()
        await images.close()
        await db.close()
        await bot.session.close()
        log.info("NEXORA to'xtatildi")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        print("\nNEXORA to'xtatildi.")
        sys.exit(0)
