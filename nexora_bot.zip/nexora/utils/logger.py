"""Logging: konsol + aylanuvchi fayl. Token va API kalitlar avtomatik yashiriladi."""
from __future__ import annotations

import logging
import re
import sys
from logging.handlers import RotatingFileHandler

from config import BASE_DIR, Config

_TOKEN_RE = re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{30,}\b")


class MaskingFormatter(logging.Formatter):
    def __init__(self, secrets: list[str], *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._secrets = [s for s in secrets if len(s) >= 8]

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        text = _TOKEN_RE.sub("***", text)
        for secret in self._secrets:
            text = text.replace(secret, "***")
        return text


def setup_logging(config: Config) -> None:
    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(exist_ok=True)
    fmt = MaskingFormatter(
        config.secrets,
        "%(asctime)s | %(levelname)-7s | %(name)s | %(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    file_handler = RotatingFileHandler(
        log_dir / "nexora.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8"
    )
    file_handler.setFormatter(fmt)

    root = logging.getLogger()
    root.setLevel(getattr(logging, config.log_level, logging.INFO))
    root.handlers.clear()
    root.addHandler(console)
    root.addHandler(file_handler)
    logging.getLogger("aiogram.event").setLevel(logging.WARNING)
