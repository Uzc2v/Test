"""/start, bosh menyu, yordam, bekor qilish."""
from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from keyboards import menus as kb
from utils import texts
from utils.helpers import show

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, is_admin: bool, is_new: bool):
    await state.clear()
    await message.answer(
        texts.welcome(message.from_user.first_name or "do'st", is_new),
        reply_markup=kb.main_menu(is_admin),
    )


@router.message(Command("menu"))
async def cmd_menu(message: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await message.answer(texts.MAIN_MENU, reply_markup=kb.main_menu(is_admin))


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext, is_admin: bool):
    await state.clear()
    await message.answer("✅ Amal bekor qilindi.\n\n" + texts.MAIN_MENU, reply_markup=kb.main_menu(is_admin))


@router.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer(texts.HELP, reply_markup=kb.only_home())


@router.callback_query(F.data == "menu:main")
async def cb_main(cb: CallbackQuery, state: FSMContext, is_admin: bool):
    await state.clear()
    await show(cb, texts.MAIN_MENU, kb.main_menu(is_admin))


@router.callback_query(F.data == "menu:help")
async def cb_help(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, texts.HELP, kb.only_home())
