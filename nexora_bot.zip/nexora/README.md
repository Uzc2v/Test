# 💠 NEXORA — Telegram bot

Bitta botda: **AI yordamchi**, **ta'lim markazi**, **ijodiy markaz**, **kundalik yordamchi**, **mini o'yinlar**, **profil/reyting** va **admin panel**. Interfeys to'liq o'zbek tilida.

**Texnologiyalar:** Python 3.10+ • aiogram 3 • SQLite (PostgreSQL'ga o'tish uchun tayyor) • asyncio • aiohttp

---

## 1. Nimalar kerak bo'ladi

| Narsa | Majburiymi? | Qayerdan olinadi |
|---|---|---|
| **Bot tokeni** | ✅ Majburiy | Telegram'da **@BotFather** → `/newbot` → nom va username bering → token beradi |
| **Admin ID** | ✅ Tavsiya | Telegram'da **@userinfobot** ga `/start` yuboring → "Id" raqamini oling |
| **AI kaliti** | AI bo'limlari uchun | Quyida (3-bo'lim). Kalitsiz AI, hikoya, she'r, tarjima ishlamaydi |
| **Rasm xizmati** | Ixtiyoriy | Standart xizmat (Pollinations) kalit talab qilmaydi |

Kalitsiz ham ishlaydigan bo'limlar: lug'at, testlar, kunlik sinov, viktorina, topishmoq, mantiq, eslatma, vazifa, reja, profil, reyting, admin panel.

---

## 2. Android'da Termux orqali o'rnatish (bosqichma-bosqich)

> ⚠️ **Termux'ni F-Droid'dan o'rnating** (https://f-droid.org/packages/com.termux/). Play Market'dagi versiyasi eskirgan va ishlamaydi.

### 2.1. Termux'ni tayyorlash
```bash
pkg update -y && pkg upgrade -y
pkg install -y python git unzip nano tmux clang make rust binutils libffi openssl
termux-setup-storage
```
`termux-setup-storage` ruxsat so'raydi — **Allow** bosing.

### 2.2. Loyihani telefonga olish
ZIP faylni (`nexora_bot.zip`) telefonning **Download** papkasiga yuklab oling, so'ng:
```bash
cp ~/storage/downloads/nexora_bot.zip ~
unzip nexora_bot.zip
cd nexora
```

### 2.3. Kutubxonalarni o'rnatish
```bash
python -m venv venv
source venv/bin/activate
pip install --upgrade pip

# Termux uchun muhim sozlamalar:
export ANDROID_API_LEVEL=$(getprop ro.build.version.sdk)
export MULTIDICT_NO_EXTENSIONS=1 YARL_NO_EXTENSIONS=1 FROZENLIST_NO_EXTENSIONS=1

pip install -r requirements.txt
```
⏳ **Birinchi marta 10–25 daqiqa ketishi mumkin** — `pydantic-core` telefonning o'zida kompilyatsiya qilinadi (Rust kerak bo'lgani shu uchun). Telefon zaryadda bo'lsin, Termux'ni yopmang.

### 2.4. Sozlamalarni kiritish
```bash
cp .env.example .env
nano .env
```
`nano` da: matnni tahrirlang → **Ctrl+O**, **Enter** (saqlash) → **Ctrl+X** (chiqish).
Kamida shularni to'ldiring:
```
BOT_TOKEN=1234567890:AA...sizning_tokeningiz
ADMIN_IDS=123456789
AI_API_KEY=gsk_...sizning_kalitingiz
```

### 2.5. Ishga tushirish
```bash
termux-wake-lock          # telefon uxlaganda ham bot ishlashi uchun
python bot.py
```
Konsolda `NEXORA ishga tushdi: @sizning_botingiz` chiqsa — tayyor. Telegram'da botingizga `/start` yuboring.

To'xtatish: **Ctrl+C**.

### 2.6. Orqa fonda ishlatish (Termux yopilsa ham)
```bash
tmux new -s nexora
source venv/bin/activate && python bot.py
```
Keyin **Ctrl+B**, so'ng **D** (tmux'dan chiqish, bot ishlashda qoladi). Qaytish: `tmux attach -t nexora`.

**Muhim:** Android sozlamalarida Termux uchun *batareya tejash (optimization)* ni **o'chiring** ("Cheklovsiz"), aks holda tizim botni o'ldirib qo'yadi. Telefon bilan 24/7 ishlash ishonchsiz — doimiy ishlashi kerak bo'lsa, arzon VPS'ga o'tkazing (o'sha buyruqlar Linux'da ham ishlaydi).

### 2.7. Yangilash
Yangi versiya ZIP'ini oching, `.env` va `data/` papkasini (bazangiz!) saqlab qoling.

---

## 3. Tashqi xizmatlarni ulash

### 🤖 AI (suhbat, tarjima, kod, tahrir, hikoya, she'r, ssenariy, promptlar)
Bot **OpenAI formatiga mos istalgan** xizmat bilan ishlaydi. Faqat 3 ta qiymat o'zgaradi:

| Xizmat | `AI_BASE_URL` | `AI_MODEL` (namuna) | Kalit |
|---|---|---|---|
| **Groq** (standart, bepul limit) | `https://api.groq.com/openai/v1` | `llama-3.3-70b-versatile` | https://console.groq.com/keys |
| **OpenAI** | `https://api.openai.com/v1` | `gpt-4o-mini` | https://platform.openai.com/api-keys |
| **OpenRouter** | `https://openrouter.ai/api/v1` | provayder ro'yxatidan | https://openrouter.ai/keys |
| **Google Gemini** | `https://generativelanguage.googleapis.com/v1beta/openai` | `gemini-2.0-flash` | https://aistudio.google.com/apikey |

> Model nomlari tez-tez yangilanadi. Xato chiqsa ("AI modeli topilmadi"), provayderning joriy model ro'yxatidan nomni oling va `AI_MODEL` ga yozing.

**Groq bilan boshlash:** console.groq.com → ro'yxatdan o'ting → *API Keys* → *Create API Key* → kalitni `.env` dagi `AI_API_KEY=` ga qo'ying. Tamom.

**Xarajatni nazorat qilish:** `AI_DAILY_LIMIT` — har bir foydalanuvchi uchun kunlik so'rovlar soni (adminlarga tegishli emas).

### 🖼 Rasm yaratish
Standart: **Pollinations** (`image.pollinations.ai`) — kalit shart emas. Bot avval AI yordamida tavsifingizni inglizcha batafsil promptga aylantiradi (AI kaliti bo'lsa), so'ng rasm yaratadi.
Eslatma: bu uchinchi tomon **bepul xizmat** — tezligi va shartlari o'zgarishi mumkin. Kalit talab qilsa, xizmatdan olib `IMAGE_API_KEY` ga yozing; boshqa xizmatga o'tish uchun `services/images.py` ni o'zgartiring (bitta fayl).

---

## 4. Botdan foydalanish

| Bo'lim | Nimalar bor |
|---|---|
| 🤖 **AI Yordamchi** | Suhbat (tarix saqlanadi), tarjima, kod yordami, matn tahriri |
| 🎓 **Ta'lim Markazi** | 40 so'zli lug'at kartochkalari, lug'at testi, ingliz tili testi (18 savol), AI o'qituvchi bilan savol-javob, **kunlik sinov** (har kuni 5 ta yangi savol) |
| 🎨 **Ijodiy Markaz** | Rasm yaratish, rasm uchun prompt, hikoya, she'r, video ssenariy, video prompt |
| 📅 **Kundalik Yordamchi** | Vaqtli eslatmalar (vaqti kelganda bot o'zi yozadi), vazifalar, kunlik reja, 7 kunlik statistika |
| 🎮 **Mini O'yinlar** | Viktorina, topishmoq, mantiqiy savollar, ball tizimi |
| 👤 **Profil / 🏆 Reyting** | ID, ism, sana, ballar, faollik grafigi, foydalanish tarixi, TOP-10 |

**Eslatma formatlari:** `18:30 Dori ichish` • `25.12 09:00 Tug'ilgan kun` • `+30 Choyni o'chirish` (30 daqiqadan keyin)

**Buyruqlar:** `/start` `/menu` `/profile` `/top` `/help` `/cancel`

### 🛡 Admin panel
`ADMIN_IDS` dagi foydalanuvchilar `/admin` yuboradi (yoki bosh menyudagi "Admin Panel" tugmasi):
- 📊 statistika (foydalanuvchilar, faol, yangi, API so'rovlari)
- 👥 so'nggi foydalanuvchilar
- 📢 **e'lon** — hammaga (matn/rasm/video/fayl), yuborishdan oldin tasdiq so'raladi
- ✉️ bitta foydalanuvchiga xabar
- 🚫 bloklash / blokdan chiqarish
- ⚙️ bo'limlarni yoqish/o'chirish (o'chirilgan bo'lim oddiy foydalanuvchilarga yopiladi, adminlar kira oladi)

---

## 5. Loyiha tuzilishi

```
nexora/
├── bot.py                 # kirish nuqtasi
├── config.py              # .env dan sozlamalar
├── requirements.txt
├── .env.example
├── handlers/              # foydalanuvchi bo'limlari
│   ├── start.py  profile.py  ai_chat.py  education.py
│   ├── quiz.py   creative.py daily.py    games.py
├── keyboards/             # menus.py, admin.py
├── database/db.py         # barcha SQL shu yerda
├── services/              # ai.py, images.py, content.py, scheduler.py
├── admin/panel.py         # admin panel
├── utils/                 # texts, middlewares, logger, timeutil, helpers
├── data/                  # SQLite bazasi (avtomatik yaratiladi)
└── logs/                  # nexora.log
```

### Yangi bo'lim qo'shish
1. `handlers/yangi.py` yarating (`router = Router()`), callback'larni `yangi:...` deb nomlang.
2. `bot.py` dagi `include_routers(...)` ga qo'shing.
3. `keyboards/menus.py` da tugma qo'shing.
4. (Ixtiyoriy) o'chirib-yoqish uchun `utils/texts.py` → `FEATURES` va `utils/helpers.py` → `feature_for_callback` ga yozing.

### PostgreSQL'ga o'tish
Barcha so'rovlar faqat `database/db.py` dagi `Database` klassida. O'sha klassning metodlarini `asyncpg` bilan qayta yozing (nomlari va qaytaradigan qiymatlari o'zgarmasin) — handlerlarga tegish shart emas. SQL'dagi `INSERT OR IGNORE/REPLACE` ni `ON CONFLICT` ga, `?` ni `$1, $2` ga almashtirasiz.

---

## 6. Xavfsizlik

- Token va API kalitlar **faqat `.env`** da; kodda yo'q. `.env` `.gitignore` da.
- Loglarda token va kalitlar avtomatik `***` ga almashtiriladi.
- Admin huquqi faqat `ADMIN_IDS` dagi Telegram ID'larga beriladi (admin handlerlari filtr bilan himoyalangan).
- Foydalanuvchi matnlari HTML'ga qo'yilishdan oldin tozalanadi (ismga `<script>` yozib bo'lmaydi).
- Spamdan himoya (tez-tez bosishni cheklash), kunlik AI limiti, bir vaqtda bitta AI so'rov.
- Bloklangan foydalanuvchilar botdan foydalana olmaydi.
- ⚠️ Foydalanuvchi AI'ga yozgan matnlar tanlangan AI provayderiga yuboriladi va suhbat tarixi sizning bazangizda saqlanadi. Foydalanuvchilarni bu haqda ogohlantirishni o'ylab ko'ring.
- Tokenni biror joyda oshkor qilib qo'ysangiz: @BotFather → `/revoke`.

---

## 7. Muammolar va yechimlar

| Muammo | Yechim |
|---|---|
| `BOT_TOKEN topilmadi` | `.env` fayli mavjudligini va `BOT_TOKEN=` dan keyin token yozilganini tekshiring |
| `BOT_TOKEN noto'g'ri` | Tokenni @BotFather'dan qayta nusxalang (bo'sh joy qo'shmang) |
| Bot javob bermaydi | Konsolda xato bormi? `logs/nexora.log` ni ko'ring. Boshqa joyda ham shu bot ishlayotgan bo'lmasin |
| "AI xizmati sozlanmagan" | `.env` da `AI_API_KEY` ni to'ldiring va botni qayta ishga tushiring |
| "AI kaliti noto'g'ri" | Kalit to'g'ri nusxalanganini va `AI_BASE_URL` shu provayderga mosligini tekshiring |
| "So'rovlar limiti tugadi" | Provayderning bepul limiti tugagan — kuting yoki boshqa provayder |
| Rasm chiqmayapti | Bepul xizmat band bo'lishi mumkin — keyinroq urinib ko'ring |
| `pip install` Termux'da xato beradi | 2.1-qadamdagi paketlar o'rnatilganini, `ANDROID_API_LEVEL` va `*_NO_EXTENSIONS` o'zgaruvchilari berilganini tekshiring; xotira yetishmasa boshqa ilovalarni yoping |
| Eslatma vaqtida kelmadi | Bot o'sha paytda ishlab turishi kerak. `TZ_OFFSET_HOURS=5` (O'zbekiston) ekanini tekshiring |
| `admin panel` ochilmayapti | `ADMIN_IDS` ga o'z ID'ingizni yozdingizmi? O'zgartirgach botni qayta ishga tushiring |

---

## 8. Ma'lum cheklovlar (halol ro'yxat)

- Suhbat holati (qaysi rejimdaligingiz) xotirada saqlanadi — bot qayta ishga tushsa, foydalanuvchi menyudan rejimni qayta tanlashi kerak. Ma'lumotlar (profil, ball, vazifa, eslatma, tarix) esa bazada saqlanadi va yo'qolmaydi.
- AI faqat matn bilan ishlaydi (rasm/ovoz yuborish qo'llab-quvvatlanmaydi).
- Savollar bazasi cheklangan (viktorina 20, topishmoq 10, mantiq 12 ta...) — `services/content.py` ga o'zingiz savol qo'shishingiz mumkin (format fayl ichida ko'rsatilgan).
- Bot Telegram **polling** rejimida ishlaydi (domen/server sertifikati kerak emas).
