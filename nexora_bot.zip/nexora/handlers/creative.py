"""Ijodiy Markaz: rasm yaratish, promptlar, hikoya, she'r, video ssenariy."""
import logging

from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import BufferedInputFile, CallbackQuery, Message
from aiogram.utils.chat_action import ChatActionSender

from config import Config
from database.db import Database
from keyboards import menus as kb
from services.ai import AIError, AIService
from services.images import ImageError, ImageService
from utils import texts
from utils.helpers import show, split_text
from utils.timeutil import day_start_ts

log = logging.getLogger("nexora.creative")
router = Router(name="creative")

TEXT_KINDS = ("imgprompt", "story", "poem", "script", "vprompt")
_busy: set[int] = set()


class CreativeStates(StatesGroup):
    waiting = State()


@router.callback_query(F.data == "menu:cr")
async def creative_menu(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, texts.CREATIVE_MENU, kb.creative_menu())


@router.callback_query(F.data.startswith("cr:") & ~F.data.in_({"cr:regen"}))
async def creative_pick(cb: CallbackQuery, state: FSMContext, ai: AIService):
    kind = cb.data.split(":")[1]
    if kind not in texts.CREATIVE_PROMPTS:
        await cb.answer()
        return
    if kind in TEXT_KINDS and not ai.enabled:
        await cb.answer("AI xizmati sozlanmagan", show_alert=True)
        await show(cb, texts.AI_NOT_CONFIGURED, kb.only_home())
        return
    await state.set_state(CreativeStates.waiting)
    await state.update_data(kind=kind, last_prompt=None)
    await show(cb, texts.CREATIVE_PROMPTS[kind] + "\n\n<i>✍️ Mavzuni yozing...</i>", kb.creative_input(kind))


async def _make_image(target: Message, user_prompt: str, ai: AIService, images: ImageService,
                      db: Database, uid: int, state: FSMContext, bot):
    status = await target.answer("⏳ Rasm yaratilmoqda, 10–40 soniya kuting...")
    final_prompt = user_prompt
    try:
        async with ChatActionSender.upload_photo(bot=bot, chat_id=target.chat.id):
            if ai.enabled:
                try:
                    final_prompt = await ai.one_shot("enhance", user_prompt, max_tokens=200, temperature=0.8)
                    await db.log(uid, "api")
                except AIError:
                    final_prompt = user_prompt  # AI ishlamasa, asl matn bilan davom etamiz
            photo = await images.generate(final_prompt)
        await db.log(uid, "image")
        await db.log(uid, "api")
        await state.update_data(last_prompt=user_prompt)
        caption = f"🖼 <b>Tayyor!</b>\n<i>Prompt:</i> {texts.esc(final_prompt[:800])}"
        await target.answer_photo(BufferedInputFile(photo, filename="nexora.png"),
                                  caption=caption, reply_markup=kb.creative_input("img", with_regen=True))
    except ImageError as e:
        await target.answer(f"⚠️ {e.user_message}", reply_markup=kb.creative_input("img"))
    except Exception:
        log.exception("Rasm yaratishda kutilmagan xato")
        await target.answer("⚠️ Rasm yaratishda kutilmagan xatolik yuz berdi. Qayta urinib ko'ring.")
    finally:
        try:
            await status.delete()
        except Exception:
            pass


async def _check_limits(message: Message, db: Database, config: Config, is_admin: bool) -> bool:
    uid = message.from_user.id
    if not is_admin:
        if not await db.feature_on("creative"):
            await message.answer("🔒 Bu bo'lim vaqtincha o'chirilgan.", reply_markup=kb.only_home())
            return False
        if await db.count_activity(uid, "api", day_start_ts()) >= config.ai_daily_limit:
            await message.answer(texts.AI_LIMIT.format(n=config.ai_daily_limit), reply_markup=kb.only_home())
            return False
    return True


@router.message(CreativeStates.waiting, F.text, ~F.text.startswith("/"))
async def creative_input(message: Message, state: FSMContext, db: Database, ai: AIService,
                         images: ImageService, config: Config, is_admin: bool):
    uid = message.from_user.id
    kind = (await state.get_data()).get("kind")
    if kind not in texts.CREATIVE_PROMPTS:
        await state.clear()
        await message.answer(texts.CREATIVE_MENU, reply_markup=kb.creative_menu())
        return
    text = message.text.strip()
    if len(text) > 1500:
        await message.answer("⚠️ Matn juda uzun (1500 belgigacha). Iltimos, qisqartiring.")
        return
    if uid in _busy:
        await message.answer(texts.AI_BUSY)
        return
    if not await _check_limits(message, db, config, is_admin):
        return

    _busy.add(uid)
    try:
        if kind == "img":
            await _make_image(message, text, ai, images, db, uid, state, message.bot)
            return
        try:
            async with ChatActionSender.typing(bot=message.bot, chat_id=message.chat.id):
                result = await ai.one_shot(kind, text, max_tokens=1800, temperature=0.9)
        except AIError as e:
            await message.answer(f"⚠️ {e.user_message}")
            return
        await db.log(uid, kind)
        await db.log(uid, "api")
        chunks = split_text(result)
        for i, chunk in enumerate(chunks):
            last = i == len(chunks) - 1
            await message.answer(chunk, parse_mode=None,
                                 reply_markup=kb.creative_input(kind) if last else None)
    finally:
        _busy.discard(uid)


@router.callback_query(F.data == "cr:regen")
async def creative_regen(cb: CallbackQuery, state: FSMContext, db: Database, ai: AIService,
                         images: ImageService, config: Config, is_admin: bool):
    data = await state.get_data()
    prompt = data.get("last_prompt")
    await cb.answer()
    if not prompt:
        await cb.message.answer("Avval rasm tavsifini yozing.", reply_markup=kb.creative_input("img"))
        return
    uid = cb.from_user.id
    if uid in _busy:
        await cb.message.answer(texts.AI_BUSY)
        return
    if not is_admin and await db.count_activity(uid, "api", day_start_ts()) >= config.ai_daily_limit:
        await cb.message.answer(texts.AI_LIMIT.format(n=config.ai_daily_limit), reply_markup=kb.only_home())
        return
    _busy.add(uid)
    try:
        await _make_image(cb.message, prompt, ai, images, db, uid, state, cb.bot)
    finally:
        _busy.discard(uid)


@router.message(CreativeStates.waiting, ~F.text)
async def creative_non_text(message: Message):
    await message.answer("📝 Iltimos, mavzuni matn ko'rinishida yozing.")
