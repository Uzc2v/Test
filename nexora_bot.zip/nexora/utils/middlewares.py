"""Kirish nazorati: ro'yxatga olish, bloklangan foydalanuvchilar, spamdan himoya, bo'lim o'chirilganligi."""
from __future__ import annotations

import logging
import time
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message, TelegramObject

from utils.helpers import feature_for_callback

log = logging.getLogger("nexora.access")


class AccessMiddleware(BaseMiddleware):
    def __init__(self, min_interval: float = 0.35):
        self._last: dict[int, float] = {}
        self._min = min_interval

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        user = getattr(event, "from_user", None)
        if user is None or user.is_bot:
            return await handler(event, data)

        db, config = data["db"], data["config"]
        data["is_new"] = await db.upsert_user(user.id, user.full_name or "", user.username)
        is_admin = user.id in config.admin_ids
        data["is_admin"] = is_admin

        if not is_admin:
            if await db.is_banned(user.id):
                if isinstance(event, CallbackQuery):
                    await event.answer("⛔ Siz botdan foydalanishdan chetlatilgansiz.", show_alert=True)
                elif isinstance(event, Message):
                    await event.answer("⛔ Kechirasiz, siz botdan foydalanishdan chetlatilgansiz.")
                return None

            now = time.monotonic()
            if now - self._last.get(user.id, 0.0) < self._min:
                if isinstance(event, CallbackQuery):
                    await event.answer()
                return None
            self._last[user.id] = now
            if len(self._last) > 5000:
                cutoff = now - 60
                self._last = {k: v for k, v in self._last.items() if v > cutoff}

        if isinstance(event, CallbackQuery) and event.data:
            feature = feature_for_callback(event.data)
            if feature and not is_admin and not await db.feature_on(feature):
                await event.answer("🔒 Bu bo'lim vaqtincha o'chirilgan.", show_alert=True)
                return None

        return await handler(event, data)
